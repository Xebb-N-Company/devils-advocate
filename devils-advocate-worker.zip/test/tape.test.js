import { describe, it, expect } from "vitest";
import { flowRow, makeFlowTape, TAPE_URL, TAPE_KEY } from "../src/store.js";
import { loadConfig } from "../src/config.js";

const coins = [{ symbol: "AERO" }, { symbol: "VVV" }, { symbol: "NOFLOW" }];
const flow = {
  AERO: { b5: 1, s5: 2, b1: 10, s1: 20, v5: 1234.6, v1: 9999.4, liq: 374149.9, c5: -0.123, c1: 0.456 },
  VVV: { b5: 23, s5: 5, b1: 281, s1: 31, v5: 1573, v1: 17132, liq: 6435713, c5: -0.31, c1: -1.13 },
};
const prices = { AERO: 0.8123456789, VVV: 17.687 };

describe("flow tape", () => {
  it("writes the browser's sbFlow row shape, skipping coins without flow", () => {
    const row = flowRow(coins, prices, flow);
    expect(Object.keys(row)).toEqual(["AERO", "VVV"]);
    expect(row.AERO).toEqual([1, 2, 10, 20, 1235, 9999, 374150, -0.12, 0.46, 0.812346]);
    expect(row.VVV).toEqual([23, 5, 281, 31, 1573, 17132, 6435713, -0.31, -1.13, 17.687]);
  });
  it("posts one ignore-duplicates upsert per minute to da_flow", async () => {
    const calls = [];
    let t = Date.UTC(2026, 10, 15, 14, 9, 8);
    const tape = makeFlowTape({ fetchImpl: async (url, init) => { calls.push({ url, init }); return { ok: true }; }, now: () => t });
    expect(tape.enabled).toBe(true);
    expect(await tape.record(coins, prices, flow)).toBe(true);
    expect(await tape.record(coins, prices, flow)).toBe(true); // same minute: no second POST
    t += 61e3;
    expect(await tape.record(coins, prices, flow)).toBe(true);
    expect(calls.length).toBe(2);
    expect(calls[0].url).toBe(`${TAPE_URL}/rest/v1/da_flow?on_conflict=minute`);
    expect(calls[0].init.headers.Prefer).toContain("resolution=ignore-duplicates");
    expect(calls[0].init.headers.apikey).toBe(TAPE_KEY);
    const body = JSON.parse(calls[0].init.body);
    expect(body.minute).toBe("2026-11-15T14:09:00.000Z");
    expect(body.data.VVV[9]).toBe(17.687);
    expect(JSON.parse(calls[1].init.body).minute).toBe("2026-11-15T14:10:00.000Z");
  });
  it("is quiet when disabled or when nothing has flow, and survives a failing endpoint", async () => {
    const off = makeFlowTape({ enabled: false, fetchImpl: async () => { throw new Error("should not be called"); } });
    expect(off.enabled).toBe(false);
    expect(await off.record(coins, prices, flow)).toBe(false);
    const empty = makeFlowTape({ fetchImpl: async () => { throw new Error("should not be called"); } });
    expect(await empty.record(coins, prices, {})).toBe(false);
    const logs = [];
    const bad = makeFlowTape({ fetchImpl: async () => ({ ok: false, status: 401, text: async () => "nope" }), log: (m) => logs.push(m) });
    expect(await bad.record(coins, prices, flow)).toBe(false);
    expect(logs[0]).toContain("401");
  });
  it("is on by default and FLOW_TAPE=0 turns it off", () => {
    const base = { SUB_ACCOUNT: "0x0000000000000000000000000000000000000001" };
    expect(loadConfig({ ...base }).flowTape.enabled).toBe(true);
    expect(loadConfig({ ...base, FLOW_TAPE: "0" }).flowTape.enabled).toBe(false);
    expect(loadConfig({ ...base, FLOW_TAPE_URL: "https://x.supabase.co/" }).flowTape.url).toBe("https://x.supabase.co");
  });
});
