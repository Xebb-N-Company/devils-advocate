// Persistence: local state.json (lots, cooldowns, tick, day cap) plus optional Supabase inserts
// into da_fills and da_pnl (see ../supabase.sql). Supabase is skipped when SUPABASE_URL / SERVICE_KEY are unset.
import { readFileSync, writeFileSync, renameSync, existsSync } from "node:fs";
import { freshState } from "./strategy.js";

export function loadState(file) {
  if (!existsSync(file)) return freshState();
  try {
    const s = JSON.parse(readFileSync(file, "utf8"));
    return { ...freshState(), ...s };
  } catch {
    return freshState();
  }
}
export function saveState(file, state) {
  const tmp = file + ".tmp";
  writeFileSync(tmp, JSON.stringify(state, (_, v) => (typeof v === "bigint" ? v.toString() : v), 2));
  renameSync(tmp, file);
}

export function makeSupabase({ url, serviceKey, desk = "", fetchImpl = fetch, log = console.error } = {}) {
  const on = !!(url && serviceKey);
  async function insert(table, row) {
    if (!on) return false;
    try {
      const r = await fetchImpl(`${url}/rest/v1/${table}`, {
        method: "POST",
        headers: { apikey: serviceKey, Authorization: `Bearer ${serviceKey}`, "content-type": "application/json", Prefer: "return=minimal" },
        body: JSON.stringify({ desk, ...row }),
      });
      if (!r.ok) log(`supabase ${table} ${r.status} ${(await r.text()).slice(0, 200)}`);
      return r.ok;
    } catch (e) {
      log("supabase failed: " + (e?.message || e));
      return false;
    }
  }
  return {
    enabled: on,
    insert,
    /** side: "buy" | "sell"; usd: clip in USD; fee: estimated fee USD; note: reason; tx: hash */
    fill: ({ at = new Date().toISOString(), side, symbol, usd, fee = 0, note = "", tx = "", mode, risk }) => insert("da_fills", { at, side, symbol, usd, fee, note, tx, mode, risk }),
    pnl: ({ at = new Date().toISOString(), nav, pnl }) => insert("da_pnl", { at, nav, pnl }),
  };
}

/**
 * Flow tape recorder. Writes one da_flow row per minute in exactly the shape the browser's sbFlow() writes:
 *   data[symbol] = [b5, s5, b1, s1, v5, v1, liq, c5, c1, price]
 * Duplicate minutes are ignored (the browser and several workers can record at once). Uses the shared tape
 * project with its publishable (anon, insert-only) key by default, the same values that ship in the site bundle,
 * so a DRY_RUN worker anywhere keeps the tape rolling while no browser tab is open. FLOW_TAPE=0 disables it.
 */
export const TAPE_URL = "https://fzcrqovnrhghnvthdfya.supabase.co";
export const TAPE_KEY = "sb_publishable_9Ucc-MM2r-4a8OFiyC5-zA_p9Wpfe69";
export function flowRow(coins, prices, flow) {
  const data = {};
  for (const c of coins) {
    const r = flow[c.symbol];
    if (!r) continue;
    data[c.symbol] = [r.b5, r.s5, r.b1, r.s1, Math.round(r.v5), Math.round(r.v1), Math.round(r.liq), +(+r.c5).toFixed(2), +(+r.c1).toFixed(2), +(prices[c.symbol] || 0).toPrecision(6)];
  }
  return data;
}
export function makeFlowTape({ enabled = true, url = TAPE_URL, key = TAPE_KEY, fetchImpl = fetch, log = console.error, now = Date.now } = {}) {
  let lastMinute = "";
  return {
    enabled: !!enabled && !!url && !!key,
    /** Records the current minute once. Returns true when a row was posted (or already recorded this minute). */
    async record(coins, prices, flow) {
      if (!enabled || !url || !key) return false;
      const minute = new Date(Math.floor(now() / 6e4) * 6e4).toISOString();
      if (minute === lastMinute) return true;
      const data = flowRow(coins, prices, flow);
      if (!Object.keys(data).length) return false;
      try {
        const r = await fetchImpl(`${url}/rest/v1/da_flow?on_conflict=minute`, {
          method: "POST",
          headers: { apikey: key, Authorization: `Bearer ${key}`, "content-type": "application/json", Prefer: "return=minimal,resolution=ignore-duplicates" },
          body: JSON.stringify({ minute, data }),
        });
        if (!r.ok) { log(`flow tape ${r.status} ${(await r.text()).slice(0, 200)}`); return false; }
        lastMinute = minute;
        return true;
      } catch (e) {
        log("flow tape failed: " + (e?.message || e));
        return false;
      }
    },
  };
}
