-- Devil's Advocate worker: fills and NAV history.
-- Inserts come from the worker with the service-role key (bypasses RLS). Anonymous visitors may read.
create table if not exists public.da_fills (
  id     bigint generated always as identity primary key,
  desk   text        not null default '',
  at     timestamptz not null default now(),
  side   text        not null check (side in ('buy','sell')),
  symbol text        not null,
  usd    numeric     not null,
  fee    numeric     not null default 0,
  note   text        not null default '',
  tx     text        not null default '',
  mode   text        not null default 'flow',
  risk   integer     not null default 50
);
create index if not exists da_fills_desk_at on public.da_fills (desk, at desc);

create table if not exists public.da_pnl (
  id   bigint generated always as identity primary key,
  desk text        not null default '',
  at   timestamptz not null default now(),
  nav  numeric     not null,
  pnl  numeric     not null
);
create index if not exists da_pnl_desk_at on public.da_pnl (desk, at desc);

alter table public.da_fills enable row level security;
alter table public.da_pnl   enable row level security;

-- Anyone (anon or authenticated) can read.
drop policy if exists "da_fills anon read" on public.da_fills;
create policy "da_fills anon read" on public.da_fills for select to anon, authenticated using (true);
drop policy if exists "da_pnl anon read" on public.da_pnl;
create policy "da_pnl anon read"   on public.da_pnl   for select to anon, authenticated using (true);

-- No insert/update/delete policies: only the service role (which bypasses RLS) can write.
revoke insert, update, delete on public.da_fills from anon, authenticated;
revoke insert, update, delete on public.da_pnl   from anon, authenticated;
grant select on public.da_fills to anon, authenticated;
grant select on public.da_pnl   to anon, authenticated;
