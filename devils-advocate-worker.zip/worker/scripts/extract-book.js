#!/usr/bin/env node
// Extracts the coin book (WZ = Uniswap V3 coins, AGG = aggregator coins) from the
// built site bundle so the worker trades exactly the same list as the browser.
// Nothing is hand-typed: addresses come straight out of the bundle.
//
//   node scripts/extract-book.js [path/to/routes-*.js] [out.json]
import { readFileSync, writeFileSync, readdirSync } from "node:fs";
import { resolve, dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const defaultDir = resolve(here, "../../site/assets");

function findBundle() {
  const files = readdirSync(defaultDir).filter((f) => /^routes-.*\.js$/.test(f));
  if (!files.length) throw new Error("No routes-*.js bundle found in " + defaultDir);
  return join(defaultDir, files[0]);
}

const src = process.argv[2] ? resolve(process.argv[2]) : findBundle();
const out = process.argv[3] ? resolve(process.argv[3]) : resolve(here, "../src/book.json");
const text = readFileSync(src, "utf8");

// Named address constants referenced inside the arrays (zZ = WETH, VZ = cbBTC, BZ = USDC ...).
const consts = {};
for (const m of text.matchAll(/[,;\n]([a-zA-Z]{2})="(0x[0-9a-fA-F]{40})"/g)) consts[m[1]] = m[2].toLowerCase();

// Grab the literal text of an array assigned to `name=[` ... `],` (balanced bracket scan).
function arrayLiteral(name) {
  const start = text.indexOf("\n" + name + "=[");
  if (start < 0) throw new Error(name + "=[ not found in bundle");
  let i = text.indexOf("[", start);
  let depth = 0;
  for (let j = i; j < text.length; j++) {
    const c = text[j];
    if (c === "[") depth++;
    else if (c === "]") {
      depth--;
      if (depth === 0) return text.slice(i, j + 1);
    }
  }
  throw new Error("unbalanced array for " + name);
}

// Parse the minified object literal into real JSON objects.
function parseCoins(lit, extra) {
  // strip // comments (the bundle keeps them inline between entries)
  const body = lit.replace(/\/\/[^\n]*/g, "");
  const objs = [];
  const re = /\{([^{}]*)\}/g;
  let m;
  while ((m = re.exec(body))) {
    const o = {};
    for (const kv of m[1].split(/,(?=[a-zA-Z_]+:)/)) {
      const idx = kv.indexOf(":");
      const k = kv.slice(0, idx).trim();
      let v = kv.slice(idx + 1).trim();
      if (v === "!0") v = true;
      else if (v === "!1") v = false;
      else if (/^"/.test(v)) v = v.slice(1, -1);
      else if (/^-?\d+(\.\d+)?$/.test(v)) v = Number(v);
      else if (consts[v]) v = consts[v];
      else throw new Error("unknown literal " + v + " in " + kv);
      o[k] = v;
    }
    if (typeof o.address === "string") o.address = o.address.toLowerCase();
    if (!/^0x[0-9a-f]{40}$/.test(o.address || "")) throw new Error("bad address in " + JSON.stringify(o));
    if (!o.symbol || !Number.isInteger(o.decimals)) throw new Error("bad coin " + JSON.stringify(o));
    objs.push({ ...o, ...extra });
  }
  return objs;
}

const v3 = parseCoins(arrayLiteral("WZ"), {});
const agg = parseCoins(arrayLiteral("AGG"), {});
for (const c of agg) if (c.agg !== true) throw new Error("AGG coin without agg flag: " + c.symbol);

const constants = {
  USDC: consts.BZ,
  WETH: consts.zZ,
  SWAP_ROUTER02: consts.HZ,
  QUOTER_V2: consts.UZ,
  RPC: (text.match(/NZ="(https:[^"]+)"/) || [])[1],
  KY_API: (text.match(/KY_API="([^"]+)"/) || [])[1],
  KY_CLIENT: (text.match(/KY_CLIENT="([^"]+)"/) || [])[1],
  FEE_TIERS: JSON.parse((text.match(/GZ=(\[[0-9,]+\])/) || [])[1] || "null"),
  LIVE_MIN_CLIP: Number((text.match(/LIVE_MIN_CLIP=([\d.]+)/) || [])[1]),
  LIVE_MAX_ROUNDTRIP: Number((text.match(/LIVE_MAX_ROUNDTRIP=([\d.]+)/) || [])[1]),
  KY_SLIPPAGE_BPS: Number((text.match(/LAUNCH_SLIPPAGE_BPS=(\d+)/) || [])[1]),
  GAS_RESERVE_ETH: (text.match(/LZ=Gh\("([\d.]+)"\)/) || [])[1],
};
for (const [k, v] of Object.entries(constants)) if (v === undefined || v === null || Number.isNaN(v)) throw new Error("could not extract " + k);

const book = { source: src.split("/").slice(-2).join("/"), extractedAt: new Date().toISOString(), constants, v3, agg };
writeFileSync(out, JSON.stringify(book, null, 1) + "\n");
console.log(`book.json: ${v3.length} Uniswap V3 coins + ${agg.length} aggregator coins -> ${out}`);
