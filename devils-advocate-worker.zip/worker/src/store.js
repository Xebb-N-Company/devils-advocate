// Persistence: local state.json (lots, cooldowns, tick, day cap) plus optional Supabase inserts
// into da_fills and da_pnl (see ../supabase.sql). Supabase is skipped when SUPABASE_URL / SERVICE_KEY are unset.
import { readFileSync, writeFileSync, renameSync, existsSync } from "node:fs";
import { freshState } from "./strategy.js";

export function loadState(file) {
  if (!existsSync(file)) return freshState();
  try {
    const s = JSON.parse(readFileSync(file, "utf8"));
    return { ...freshState(), ...s };
  } catch {
    return freshState();
  }
}
export function saveState(file, state) {
  const tmp = file + ".tmp";
  writeFileSync(tmp, JSON.stringify(state, (_, v) => (typeof v === "bigint" ? v.toString() : v), 2));
  renameSync(tmp, file);
}

export function makeSupabase({ url, serviceKey, desk = "", fetchImpl = fetch, log = console.error } = {}) {
  const on = !!(url && serviceKey);
  async function insert(table, row) {
    if (!on) return false;
    try {
      const r = await fetchImpl(`${url}/rest/v1/${table}`, {
        method: "POST",
        headers: { apikey: serviceKey, Authorization: `Bearer ${serviceKey}`, "content-type": "application/json", Prefer: "return=minimal" },
        body: JSON.stringify({ desk, ...row }),
      });
      if (!r.ok) log(`supabase ${table} ${r.status} ${(await r.text()).slice(0, 200)}`);
      return r.ok;
    } catch (e) {
      log("supabase failed: " + (e?.message || e));
      return false;
    }
  }
  return {
    enabled: on,
    /** side: "buy" | "sell"; usd: clip in USD; fee: estimated fee USD; note: reason; tx: hash */
    fill: ({ at = new Date().toISOString(), side, symbol, usd, fee = 0, note = "", tx = "", mode, risk }) => insert("da_fills", { at, side, symbol, usd, fee, note, tx, mode, risk }),
    pnl: ({ at = new Date().toISOString(), nav, pnl }) => insert("da_pnl", { at, nav, pnl }),
  };
}
