// Base chain access: balances, Uniswap V3 quotes (QuoterV2), call encoding for approve / SwapRouter02
// exactInputSingle, KyberSwap aggregator route + build, round-trip checks and the price book.
// Mirrors MQ/NQ/PQ/zQ/RQ/liveBuy/liveSell/liveRoundTrip/kyRoute/kyBuild/kySwap/kyRoundTrip/kyPrice/livePrices_.
import { createPublicClient, http, encodeFunctionData, formatUnits, parseEther } from "viem";
import { base } from "viem/chains";
import { readFileSync } from "node:fs";
import { dsPrices } from "./flow.js";

export const BOOK = JSON.parse(readFileSync(new URL("./book.json", import.meta.url), "utf8"));
export const USDC = BOOK.constants.USDC;
export const WETH = BOOK.constants.WETH;
export const SWAP_ROUTER02 = BOOK.constants.SWAP_ROUTER02;
export const QUOTER_V2 = BOOK.constants.QUOTER_V2;
export const FEE_TIERS = BOOK.constants.FEE_TIERS;         // [500, 3000, 10000]
export const KY_API = BOOK.constants.KY_API;
export const KY_CLIENT = BOOK.constants.KY_CLIENT;
export const KY_SLIPPAGE_BPS = BOOK.constants.KY_SLIPPAGE_BPS; // 300
export const GAS_RESERVE_WEI = parseEther(BOOK.constants.GAS_RESERVE_ETH);
export const MAX_UINT = 2n ** 256n - 1n;
export const MIN_OUT_BPS = 985n; // 1.5% min-out on Uniswap legs, as in zQ

/** All tradeable coins: Uniswap V3 book then aggregator book (liveAllCoins without launches). */
export function allCoins() {
  return [...BOOK.v3, ...BOOK.agg];
}

export const erc20Abi = [
  { type: "function", name: "balanceOf", stateMutability: "view", inputs: [{ name: "account", type: "address" }], outputs: [{ type: "uint256" }] },
  { type: "function", name: "allowance", stateMutability: "view", inputs: [{ name: "owner", type: "address" }, { name: "spender", type: "address" }], outputs: [{ type: "uint256" }] },
  { type: "function", name: "approve", stateMutability: "nonpayable", inputs: [{ name: "spender", type: "address" }, { name: "amount", type: "uint256" }], outputs: [{ type: "bool" }] },
  { type: "function", name: "transfer", stateMutability: "nonpayable", inputs: [{ name: "to", type: "address" }, { name: "amount", type: "uint256" }], outputs: [{ type: "bool" }] },
];
export const routerAbi = [{
  type: "function", name: "exactInputSingle", stateMutability: "payable",
  inputs: [{ name: "params", type: "tuple", components: [
    { name: "tokenIn", type: "address" }, { name: "tokenOut", type: "address" }, { name: "fee", type: "uint24" }, { name: "recipient", type: "address" },
    { name: "amountIn", type: "uint256" }, { name: "amountOutMinimum", type: "uint256" }, { name: "sqrtPriceLimitX96", type: "uint160" }] }],
  outputs: [{ name: "amountOut", type: "uint256" }],
}];
export const quoterAbi = [{
  type: "function", name: "quoteExactInputSingle", stateMutability: "nonpayable",
  inputs: [{ name: "params", type: "tuple", components: [
    { name: "tokenIn", type: "address" }, { name: "tokenOut", type: "address" }, { name: "amountIn", type: "uint256" }, { name: "fee", type: "uint24" }, { name: "sqrtPriceLimitX96", type: "uint160" }] }],
  outputs: [{ name: "amountOut", type: "uint256" }, { name: "sqrtPriceX96After", type: "uint160" }, { name: "initializedTicksCrossed", type: "uint32" }, { name: "gasEstimate", type: "uint256" }],
}];

export function makeClient(rpcUrl = BOOK.constants.RPC) {
  return createPublicClient({ chain: base, transport: http(rpcUrl, { batch: true }), batch: { multicall: { wait: 16 } } });
}

// ---------- units (liveUnits / liveNum) ----------
export function toUnits(e, decimals) {
  const n = Number(e);
  if (!Number.isFinite(n) || n <= 0) return 0n;
  const r = Math.min(decimals, 12);
  const a = BigInt(n.toFixed(r).replace(".", ""));
  return decimals > r ? a * 10n ** BigInt(decimals - r) : a;
}
export function toNum(raw, decimals) {
  return Number(formatUnits(raw, decimals));
}

// ---------- quotes ----------
export async function quote(client, tokenIn, tokenOut, amountIn, fee) {
  const r = await client.readContract({ address: QUOTER_V2, abi: quoterAbi, functionName: "quoteExactInputSingle", args: [{ tokenIn, tokenOut, amountIn, fee, sqrtPriceLimitX96: 0n }] });
  return Array.isArray(r) ? r[0] : r;
}
/** NQ: try the configured fee first, then every tier, keep the deepest. */
export async function bestQuote(client, tokenIn, tokenOut, amountIn, fee) {
  if (fee) {
    try { const out = await quote(client, tokenIn, tokenOut, amountIn, fee); if (out > 0n) return { fee, out }; } catch { /* fall through */ }
  }
  let best = null;
  for (const f of FEE_TIERS) {
    try { const out = await quote(client, tokenIn, tokenOut, amountIn, f); if (!best || out > best.out) best = { fee: f, out }; } catch { continue; }
  }
  return best;
}
/** PQ: ETH/USD from the WETH/USDC 0.05% pool with a 0.001 ETH probe. */
export async function ethUsd(client) {
  const q = await bestQuote(client, WETH, USDC, parseEther("0.001"), 500);
  return q ? toNum(q.out, 6) / 0.001 : 0;
}

// ---------- balances ----------
export async function balanceOf(client, token, account) {
  return client.readContract({ address: token, abi: erc20Abi, functionName: "balanceOf", args: [account] });
}
export async function allowance(client, token, owner, spender) {
  return client.readContract({ address: token, abi: erc20Abi, functionName: "allowance", args: [owner, spender] });
}
/** Everything the tick needs: ETH, USDC, every coin's raw balance (multicall-batched). */
export async function readBalances(client, account, coins, mainAccount) {
  const [eth, usdc, mainUsdc, ...toks] = await Promise.all([
    client.getBalance({ address: account }),
    balanceOf(client, USDC, account),
    mainAccount ? balanceOf(client, USDC, mainAccount).catch(() => 0n) : Promise.resolve(0n),
    ...coins.map((c) => balanceOf(client, c.address, account).catch(() => 0n)),
  ]);
  const tokens = {};
  coins.forEach((c, i) => { tokens[c.symbol] = { raw: toks[i], amount: toNum(toks[i], c.decimals) }; });
  return { ethWei: eth, eth: toNum(eth, 18), usdcRaw: usdc, usdc: toNum(usdc, 6), mainUsdc: toNum(mainUsdc, 6), tokens };
}

// ---------- prices (livePrices_) ----------
/**
 * V3 coins: QuoterV2 probe (~$5 worth, or 1000 units when unknown) through their pool side.
 * Aggregator coins: DexScreener best pair, KyberSwap route as the fallback.
 * Returns { prices (by symbol), flow (by symbol, raw DexScreener flow records) }.
 */
export async function priceBook(client, { prevPrices = {}, fetchImpl = fetch } = {}) {
  const eth = await ethUsd(client);
  const prices = { WETH: eth };
  const v3 = BOOK.v3.filter((c) => c.symbol !== "WETH");
  const quoted = await Promise.all(v3.map(async (c) => {
    const probe = prevPrices[c.symbol] > 0 ? 5 / prevPrices[c.symbol] : 1e3;
    let units = toUnits(probe, c.decimals);
    if (units <= 0n) units = 10n ** BigInt(c.decimals);
    const baseAddr = c.base === "USDC" ? USDC : WETH, baseDec = c.base === "USDC" ? 6 : 18;
    try {
      const out = await quote(client, c.address, baseAddr, units, c.fee);
      const s = toNum(out, baseDec) / toNum(units, c.decimals);
      return [c.symbol, c.base === "USDC" ? s : s * eth];
    } catch { return [c.symbol, 0]; }
  }));
  for (const [s, p] of quoted) prices[s] = p;
  const coins = allCoins();
  const ds = await dsPrices(coins.map((c) => c.address), fetchImpl);
  const miss = BOOK.agg.filter((c) => !(ds.prices[c.address] > 0));
  for (const c of BOOK.agg) if (ds.prices[c.address] > 0) prices[c.symbol] = ds.prices[c.address];
  for (let i = 0; i < miss.length; i += 4) {
    const chunk = miss.slice(i, i + 4);
    const r = await Promise.all(chunk.map(async (c) => [c.symbol, await kyPrice(c, prevPrices[c.symbol], fetchImpl)]));
    for (const [s, p] of r) prices[s] = p;
    if (i + 4 < miss.length) await new Promise((res) => setTimeout(res, 300));
  }
  const flow = {};
  for (const c of coins) if (ds.flow[c.address]) flow[c.symbol] = ds.flow[c.address];
  return { prices, flow, ethUsd: eth };
}

// ---------- call encoding ----------
export function approveCall(token, spender) {
  return { to: token, data: encodeFunctionData({ abi: erc20Abi, functionName: "approve", args: [spender, MAX_UINT] }), value: 0n };
}
export function exactInputSingleCall({ tokenIn, tokenOut, fee, recipient, amountIn, amountOutMinimum }) {
  return {
    to: SWAP_ROUTER02,
    data: encodeFunctionData({ abi: routerAbi, functionName: "exactInputSingle", args: [{ tokenIn, tokenOut, fee, recipient, amountIn, amountOutMinimum, sqrtPriceLimitX96: 0n }] }),
    value: 0n,
  };
}

/**
 * zQ as a call plan: quote, then [approve (if allowance short)] + exactInputSingle with 1.5% min-out.
 * The caller sends the calls as ONE atomic batch.
 */
export async function planV3Swap(client, { tokenIn, tokenOut, amountIn, recipient, fee }) {
  const q = await bestQuote(client, tokenIn, tokenOut, amountIn, fee);
  if (!q || q.out <= 0n) throw new Error("No Base pool quote.");
  const calls = [];
  const have = await allowance(client, tokenIn, recipient, SWAP_ROUTER02);
  if (have < amountIn) calls.push(approveCall(tokenIn, SWAP_ROUTER02));
  calls.push(exactInputSingleCall({ tokenIn, tokenOut, fee: q.fee, recipient, amountIn, amountOutMinimum: (q.out * MIN_OUT_BPS) / 1000n }));
  return { calls, out: q.out, fee: q.fee, kind: "v3", tokenIn, tokenOut, amountIn };
}

// ---------- KyberSwap aggregator ----------
export async function kyRoute(tokenIn, tokenOut, amountIn, fetchImpl = fetch) {
  const r = await fetchImpl(`${KY_API}/routes?tokenIn=${tokenIn}&tokenOut=${tokenOut}&amountIn=${amountIn.toString()}`, { headers: { "x-client-id": KY_CLIENT } });
  const j = await r.json();
  if (j.code !== 0 || !j.data?.routeSummary) throw new Error(j.message || "No aggregator route.");
  return j.data;
}
export async function kyBuild(route, account, fetchImpl = fetch) {
  const r = await fetchImpl(`${KY_API}/route/build`, {
    method: "POST", headers: { "content-type": "application/json", "x-client-id": KY_CLIENT },
    body: JSON.stringify({ routeSummary: route.routeSummary, sender: account, recipient: account, slippageTolerance: KY_SLIPPAGE_BPS, deadline: Math.floor(Date.now() / 1e3) + 120, source: KY_CLIENT }),
  });
  const j = await r.json();
  if (j.code !== 0 || !j.data?.data) throw new Error(j.message || "Aggregator build failed.");
  return j.data;
}
/** kySwap as a call plan: [approve router if short] + router call. */
export async function planKySwap(client, { tokenIn, tokenOut, amountIn, recipient, fetchImpl = fetch }) {
  const route = await kyRoute(tokenIn, tokenOut, amountIn, fetchImpl);
  const built = await kyBuild(route, recipient, fetchImpl);
  const calls = [];
  const have = await allowance(client, tokenIn, recipient, built.routerAddress);
  if (have < amountIn) calls.push(approveCall(tokenIn, built.routerAddress));
  calls.push({ to: built.routerAddress, data: built.data, value: BigInt(built.transactionValue || 0) });
  return { calls, out: BigInt(built.amountOut || 0), router: built.routerAddress, kind: "kyber", tokenIn, tokenOut, amountIn };
}
export async function kyRoundTrip(tok, units, fetchImpl = fetch) {
  try {
    const a = await kyRoute(USDC, tok.address, units, fetchImpl);
    const b = await kyRoute(tok.address, USDC, BigInt(a.routeSummary.amountOut), fetchImpl);
    return toNum(BigInt(b.routeSummary.amountOut), 6) / toNum(units, 6);
  } catch { return 0; }
}
export async function kyPrice(tok, prev, fetchImpl = fetch) {
  const probe = prev > 0 ? 5 / prev : 1e3;
  let units = toUnits(probe, tok.decimals);
  if (units <= 0n) units = 10n ** BigInt(tok.decimals);
  try {
    const r = await kyRoute(tok.address, USDC, units, fetchImpl);
    return toNum(BigInt(r.routeSummary.amountOut), 6) / toNum(units, tok.decimals);
  } catch { return 0; }
}

/** liveRoundTrip: USDC -> coin -> USDC through Uniswap V3 quotes; fraction that survives (0 = no quote). */
export async function v3RoundTrip(client, tok, units) {
  try {
    const baseAddr = tok.base === "USDC" ? USDC : WETH;
    let r = units;
    if (tok.base !== "USDC") r = await quote(client, USDC, WETH, units, 500);
    if (tok.symbol === "WETH") return toNum(await quote(client, WETH, USDC, r, 500), 6) / toNum(units, 6);
    const i = await quote(client, baseAddr, tok.address, r, tok.fee);
    const a = await quote(client, tok.address, baseAddr, i, tok.fee);
    const o = tok.base === "USDC" ? a : await quote(client, WETH, USDC, a, 500);
    return toNum(o, 6) / toNum(units, 6);
  } catch { return 0; }
}
export function roundTrip(client, tok, units, fetchImpl = fetch) {
  return tok.agg ? kyRoundTrip(tok, units, fetchImpl) : v3RoundTrip(client, tok, units);
}

/**
 * Build the list of atomic batches that a buy (USDC -> coin) needs, as the browser does it:
 *   WETH itself:   one batch  USDC->WETH @500
 *   base==USDC:    one batch  USDC->coin @fee
 *   base==WETH:    two batches USDC->WETH @500, then WETH->coin @fee with the WETH balance delta
 *   agg:           one batch through KyberSwap
 * Each step is { plan: ({dryOut}) => Promise<{calls,...}>, label, before? }. Steps run sequentially because
 * the second leg needs the first leg's on-chain output (or, in DRY_RUN, the first leg's quote).
 */
export function buySteps(client, tok, units, account, fetchImpl = fetch) {
  if (tok.agg) return [{ label: `USDC->${tok.symbol} via KyberSwap`, plan: () => planKySwap(client, { tokenIn: USDC, tokenOut: tok.address, amountIn: units, recipient: account, fetchImpl }) }];
  if (tok.symbol === "WETH") return [{ label: "USDC->WETH @500", plan: () => planV3Swap(client, { tokenIn: USDC, tokenOut: WETH, amountIn: units, recipient: account, fee: 500 }) }];
  if (tok.base === "USDC") return [{ label: `USDC->${tok.symbol} @${tok.fee}`, plan: () => planV3Swap(client, { tokenIn: USDC, tokenOut: tok.address, amountIn: units, recipient: account, fee: tok.fee }) }];
  let before = 0n;
  return [
    { label: "USDC->WETH @500 (leg 1)", before: async () => { before = await balanceOf(client, WETH, account); }, plan: () => planV3Swap(client, { tokenIn: USDC, tokenOut: WETH, amountIn: units, recipient: account, fee: 500 }) },
    { label: `WETH->${tok.symbol} @${tok.fee} (leg 2)`, plan: async ({ dryOut } = {}) => {
      // DRY_RUN: leg 1 never landed, so use its quote as the delta.
      const delta = dryOut !== undefined ? dryOut : (await balanceOf(client, WETH, account)) - before;
      if (delta <= 0n) throw new Error("WETH leg did not land.");
      return planV3Swap(client, { tokenIn: WETH, tokenOut: tok.address, amountIn: delta, recipient: account, fee: tok.fee });
    } },
  ];
}
/** Sell (coin -> USDC, full raw amount), same shape as buySteps. */
export function sellSteps(client, tok, raw, account, fetchImpl = fetch) {
  if (tok.agg) return [{ label: `${tok.symbol}->USDC via KyberSwap`, plan: () => planKySwap(client, { tokenIn: tok.address, tokenOut: USDC, amountIn: raw, recipient: account, fetchImpl }) }];
  if (tok.symbol === "WETH") return [{ label: "WETH->USDC @500", plan: () => planV3Swap(client, { tokenIn: WETH, tokenOut: USDC, amountIn: raw, recipient: account, fee: 500 }) }];
  if (tok.base === "USDC") return [{ label: `${tok.symbol}->USDC @${tok.fee}`, plan: () => planV3Swap(client, { tokenIn: tok.address, tokenOut: USDC, amountIn: raw, recipient: account, fee: tok.fee }) }];
  let before = 0n;
  return [
    { label: `${tok.symbol}->WETH @${tok.fee} (leg 1)`, before: async () => { before = await balanceOf(client, WETH, account); }, plan: () => planV3Swap(client, { tokenIn: tok.address, tokenOut: WETH, amountIn: raw, recipient: account, fee: tok.fee }) },
    { label: "WETH->USDC @500 (leg 2)", plan: async ({ dryOut } = {}) => {
      const delta = dryOut !== undefined ? dryOut : (await balanceOf(client, WETH, account)) - before;
      if (delta <= 0n) throw new Error("WETH leg did not land.");
      return planV3Swap(client, { tokenIn: WETH, tokenOut: USDC, amountIn: delta, recipient: account, fee: 500 });
    } },
  ];
}
