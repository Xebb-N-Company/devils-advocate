// Environment → config. Every knob the worker uses lives here.
// DRY_RUN defaults to 1: the worker never POSTs to the Coinbase wallet RPC unless DRY_RUN=0.
import { KEEL_MODES } from "./params.js";

function num(name, dflt) {
  const v = process.env[name];
  if (v === undefined || v === "") return dflt;
  const n = Number(v);
  if (!Number.isFinite(n)) throw new Error(`${name} must be a number, got "${v}"`);
  return n;
}
function bool(name, dflt) {
  const v = process.env[name];
  if (v === undefined || v === "") return dflt;
  return !(v === "0" || v.toLowerCase() === "false" || v.toLowerCase() === "no");
}
function addr(name, required) {
  const v = (process.env[name] || "").trim();
  if (!v) {
    if (required) throw new Error(`${name} is required`);
    return "";
  }
  if (!/^0x[0-9a-fA-F]{40}$/.test(v)) throw new Error(`${name} must be a 0x address`);
  return v.toLowerCase();
}

export function loadConfig(env = process.env) {
  const prev = process.env;
  process.env = env;
  try {
    const dryRun = bool("DRY_RUN", true);
    const mode = (env.MODE || "flow").toLowerCase();
    if (!KEEL_MODES[mode]) throw new Error(`MODE must be one of ${Object.keys(KEEL_MODES).join(", ")}`);
    const risk = Math.round(num("RISK", 50));
    if (risk < 0 || risk > 100) throw new Error("RISK must be 0..100");
    const key = (env.OWNER_PRIVATE_KEY || "").trim();
    if (!dryRun && !/^0x[0-9a-fA-F]{64}$/.test(key)) throw new Error("OWNER_PRIVATE_KEY (0x + 64 hex) is required when DRY_RUN=0");
    if (key && !/^0x[0-9a-fA-F]{64}$/.test(key)) throw new Error("OWNER_PRIVATE_KEY must be 0x + 64 hex chars");
    return {
      dryRun,
      once: bool("ONCE", false),
      ownerPrivateKey: key,
      subAccount: addr("SUB_ACCOUNT", true),
      mainAccount: addr("MAIN_ACCOUNT", !dryRun),
      budgetUsdc: num("BUDGET_USDC", 25),
      mode,
      risk,
      tickSeconds: num("TICK_SECONDS", 60),
      paymasterUrl: (env.PAYMASTER_URL || "").trim(),
      rpcUrl: (env.BASE_RPC_URL || "https://base-rpc.publicnode.com").trim(),
      coinbaseRpcUrl: (env.COINBASE_RPC_URL || "https://rpc.wallet.coinbase.com").trim(),
      telegram: {
        token: (env.TELEGRAM_BOT_TOKEN || "").trim(),
        chatId: (env.TELEGRAM_CHAT_ID || "").trim(),
      },
      supabase: {
        url: (env.SUPABASE_URL || "").trim().replace(/\/$/, ""),
        serviceKey: (env.SUPABASE_SERVICE_KEY || "").trim(),
      },
      stateFile: (env.STATE_FILE || "./state.json").trim(),
      deskName: (env.DESK_NAME || "").trim(),
    };
  } finally {
    process.env = prev;
  }
}
