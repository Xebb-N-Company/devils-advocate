// Coinbase wallet RPC: send an atomic batch of calls from the sub account, signed by the worker's
// owner key, exactly as @base-org/account 2.6.0 does in FB (case "wallet_sendCalls"):
//
//   wallet_prepareCalls  { version:"1.0", calls, chainId, from: sub, capabilities:{ funding:[spendPermission...] } }
//     -> { type, userOp, chainId, signatureRequest:{ hash } }
//   owner.sign({ hash })                      (raw secp256k1 signature of the hash, no EIP-191 prefix)
//   wallet_sendPreparedCalls { version:"1.0", type, data:userOp, chainId, signature:{ type:"secp256k1", data:{ address, signature } } }
//     -> [ callsId ]
//   wallet_getCallsStatus [ callsId ]  until status 200 (receipts[0].transactionHash) or >= 400 (failed)
//
// Notes from reading the SDK:
//  * The SDK decodes signatureRequest.hash with hexToString (viem `Dt`) before signing: the wallet
//    returns the hash as hex-encoded UTF-8 text of the "0x…" string. We do the same, and fall back to
//    the raw value when it already is a 32-byte hash.
//  * The funding capability (type "spendPermission", autoApply, sources:[main], PREFER_DIRECT_BALANCE)
//    is what lets the sub account draw USDC / ETH from the main wallet through the spend permission
//    the user granted in the browser.
//  * The SDK adds capabilities.attribution = { suffix } only when the dapp configured
//    preference.attribution (CB). The site does not, so no attribution is attached here.
//  * paymasterService: the SDK merges { paymasterService: { url } } into capabilities when a paymaster
//    URL is configured (EB / vB). PAYMASTER_URL does the same here.
//  * Requests carry the SDK headers X-Cbw-Sdk-Version / X-Cbw-Sdk-Platform (nB).
import { privateKeyToAccount } from "viem/accounts";
import { hexToString, isHex, toHex } from "viem";

export const COINBASE_RPC = "https://rpc.wallet.coinbase.com";
export const CHAIN_ID_HEX = "0x2105"; // Base mainnet 8453
export const SDK_VERSION = "2.6.0";
export const SDK_PLATFORM = "@base-org/account";

export function ownerFromKey(privateKey) {
  return privateKeyToAccount(privateKey);
}

/** Serialize a call for the wallet RPC: hex value, "0x" data default. */
export function serializeCall(c) {
  return { to: c.to, data: c.data || "0x", value: toHex(BigInt(c.value ?? 0)) };
}

export function buildCapabilities({ mainAccount, paymasterUrl }) {
  const caps = {};
  if (paymasterUrl) caps.paymasterService = { url: paymasterUrl };
  if (mainAccount) caps.funding = [{ type: "spendPermission", data: { autoApply: true, sources: [mainAccount], preference: "PREFER_DIRECT_BALANCE" } }];
  return caps;
}

export function prepareCallsRequest({ calls, subAccount, mainAccount, paymasterUrl, chainId = CHAIN_ID_HEX }) {
  return {
    method: "wallet_prepareCalls",
    params: [{ version: "1.0", calls: calls.map(serializeCall), chainId, from: subAccount, capabilities: buildCapabilities({ mainAccount, paymasterUrl }) }],
  };
}

/** The hash to sign, decoded like the SDK does. */
export function hashToSign(h) {
  if (typeof h !== "string") throw new Error("signatureRequest.hash missing");
  if (isHex(h) && h.length === 66) return h; // already a bare 32-byte hash
  const decoded = hexToString(h);
  if (isHex(decoded) && decoded.length === 66) return decoded;
  throw new Error("Unexpected signatureRequest.hash format: " + h.slice(0, 20));
}

export function signatureEnvelope(owner, signature) {
  return { type: "secp256k1", data: { address: owner.address, signature } };
}

export function makeCoinbase({ owner, subAccount, mainAccount, paymasterUrl = "", rpcUrl = COINBASE_RPC, fetchImpl = fetch, sleep = (ms) => new Promise((r) => setTimeout(r, ms)), log = () => {} }) {
  let id = 0;
  async function rpc(method, params) {
    const body = { jsonrpc: "2.0", id: ++id, method, params };
    const r = await fetchImpl(rpcUrl, {
      method: "POST", mode: "cors",
      headers: { "Content-Type": "application/json", "X-Cbw-Sdk-Version": SDK_VERSION, "X-Cbw-Sdk-Platform": SDK_PLATFORM },
      body: JSON.stringify(body),
    });
    const j = await r.json();
    if (j.error) {
      const e = new Error(j.error.message || "Coinbase RPC error");
      e.code = j.error.code; e.data = j.error.data;
      throw e;
    }
    return j.result;
  }

  async function prepare(calls) {
    const req = prepareCallsRequest({ calls, subAccount, mainAccount, paymasterUrl });
    return rpc(req.method, req.params);
  }
  async function send(prepared) {
    const hash = hashToSign(prepared.signatureRequest?.hash);
    const signature = await owner.sign({ hash });
    const res = await rpc("wallet_sendPreparedCalls", [{ version: "1.0", type: prepared.type, data: prepared.userOp, chainId: prepared.chainId, signature: signatureEnvelope(owner, signature) }]);
    const callsId = Array.isArray(res) ? res[0] : res?.id || res;
    if (!callsId) throw new Error("Coinbase Wallet returned no batch id.");
    return callsId;
  }
  async function status(callsId) {
    return rpc("wallet_getCallsStatus", [callsId]);
  }
  async function waitFor(callsId, { attempts = 90, intervalMs = 2000 } = {}) {
    for (let i = 0; i < attempts; i++) {
      const s = await status(callsId);
      const st = s && s.status;
      if (st === 200 || st === "CONFIRMED") {
        const tx = s.receipts && s.receipts[0] && s.receipts[0].transactionHash;
        if (tx) return tx;
        throw new Error("Batch confirmed without a receipt.");
      }
      if ((typeof st === "number" && st >= 400) || st === "FAILED") throw new Error("Coinbase Wallet batch failed (" + st + ").");
      await sleep(intervalMs);
    }
    throw new Error("Timed out waiting for the Coinbase Wallet batch.");
  }
  /** Full flow: prepare -> sign -> send -> wait. Returns the transaction hash. */
  async function sendCalls(calls) {
    log("prepare", calls.length + " call(s)");
    const prepared = await prepare(calls);
    const callsId = await send(prepared);
    log("sent", callsId);
    return waitFor(callsId);
  }
  return { rpc, prepare, send, status, waitFor, sendCalls, owner, subAccount };
}
