#!/usr/bin/env node
// Prints a fresh secp256k1 owner key + address. Add the ADDRESS as an owner of the sub account from
// the website; put the PRIVATE KEY in OWNER_PRIVATE_KEY on the server. Anyone holding this key can
// spend the sub account (and, through the spend permission, the budgeted USDC/ETH of the main wallet).
import { generatePrivateKey, privateKeyToAccount } from "viem/accounts";

const pk = generatePrivateKey();
const acct = privateKeyToAccount(pk);
console.log("Owner address (add this as a sub-account owner on the site):");
console.log("  " + acct.address);
console.log("");
console.log("OWNER_PRIVATE_KEY (keep secret, never commit, never paste in chat):");
console.log("  " + pk);
