// DexScreener batch fetch + flow score. Mirrors dsPrices() / flowScore() in the site bundle.
//
// dsPrices: for every 30 token addresses, GET https://api.dexscreener.com/tokens/v1/base/{a,b,c}.
// Price = the most liquid pair's priceUsd. Flow = txns/volume/liquidity summed across ALL pairs of the token.

export const DS_URL = "https://api.dexscreener.com/tokens/v1/base/";

/**
 * @param {string[]} addresses lower-case token addresses
 * @param {(url:string)=>Promise<Response>} fetchImpl
 * @returns {Promise<{prices: Record<string, number>, flow: Record<string, object>}>}
 *   prices: address -> USD price (most liquid pair). flow: address -> {b5,s5,b1,s1,v5,v1,v24,liq,pairs,c5,c1,c6,at}
 */
export async function dsPrices(addresses, fetchImpl = fetch) {
  const prices = {};
  const flow = {};
  for (let n = 0; n < addresses.length; n += 30) {
    try {
      const r = await fetchImpl(DS_URL + addresses.slice(n, n + 30).join(","));
      const i = r.ok ? await r.json() : [];
      if (!Array.isArray(i)) continue;
      const best = {}, agg = {};
      for (const t of i) {
        const a = (t.baseToken?.address || "").toLowerCase();
        const px = +t.priceUsd, liq = +(t.liquidity?.usd || 0);
        if (!a) continue;
        if (px > 0 && (!best[a] || liq > best[a].liq)) best[a] = { px, liq, c5: +(t.priceChange?.m5 || 0), c1: +(t.priceChange?.h1 || 0), c6: +(t.priceChange?.h6 || 0) };
        const o = agg[a] || (agg[a] = { b5: 0, s5: 0, b1: 0, s1: 0, v5: 0, v1: 0, v24: 0, liq: 0, pairs: 0 });
        o.b5 += +(t.txns?.m5?.buys || 0); o.s5 += +(t.txns?.m5?.sells || 0);
        o.b1 += +(t.txns?.h1?.buys || 0); o.s1 += +(t.txns?.h1?.sells || 0);
        o.v5 += +(t.volume?.m5 || 0); o.v1 += +(t.volume?.h1 || 0); o.v24 += +(t.volume?.h24 || 0);
        o.liq += liq; o.pairs++;
      }
      for (const [a, b] of Object.entries(best)) prices[a] = b.px;
      for (const [a, o] of Object.entries(agg)) {
        const b = best[a] || {};
        flow[a] = { ...o, c5: b.c5 || 0, c1: b.c1 || 0, c6: b.c6 || 0, at: Date.now() };
      }
    } catch {
      // same as the browser: a failed batch just yields nothing this tick
    }
  }
  return { prices, flow };
}

/**
 * Flow score: buy-pressure imbalance in the last 5 minutes and hour, with volume acceleration
 * (5-minute pace vs the hourly pace). Returns null when there is no flow record.
 */
export function flowScore(t) {
  if (!t) return null;
  const n = t.b5 + t.s5, r = t.b1 + t.s1;
  const i = n ? (t.b5 - t.s5) / n : 0, a = r ? (t.b1 - t.s1) / r : 0;
  const o = t.v1 > 0 ? (t.v5 * 12) / t.v1 : 0;
  return { imb5: i, imb1: a, accel: o, n5: n, n1: r, v1: t.v1, liq: t.liq, c5: t.c5, c1: t.c1, score: i * Math.min(o, 4) };
}
