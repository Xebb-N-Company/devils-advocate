// Pure strategy: given balances, prices, flow, state and params, decide what to do.
// This is a transcription of the live tick (VQ) in the site bundle, Flow branch fully,
// with the shared position bookkeeping (lots, cooldown, daily loss cap). The Classic branch
// has a slot (see pickEntriesClassic) but is not wired in yet.
//
// Nothing here touches the network. Execution (quotes, swaps, Coinbase RPC) lives in index.js.
import { flowScore } from "./flow.js";
import { LIVE_MIN_CLIP, LIVE_MAX_ROUNDTRIP } from "./params.js";

export const DAY_MS = 864e5;

export function freshState() {
  return { tick: 0, lots: {}, cool: {}, ref: {}, day: null, dailyFills: [] };
}

// liveVolOf(): realized vol of the 1-minute price history. We keep no history yet, so this is the
// browser's default (.02) which, with stopVolMult = 0 in Flow, yields stop = stopMin.
function volOf(hist) {
  if (!hist || hist.length < 4) return 0.02;
  const n = [];
  for (let e = 1; e < hist.length; e++) if (hist[e - 1] > 0 && hist[e] > 0) n.push(Math.log(hist[e] / hist[e - 1]));
  if (n.length < 3) return 0.02;
  const r = n.reduce((a, b) => a + b, 0) / n.length;
  const i = Math.sqrt(n.reduce((a, b) => a + (b - r) * (b - r), 0) / n.length);
  return Math.min(0.2, Math.max(0.004, i));
}

export function defaultStop(params, hist) {
  return Math.min(params.stopMax, Math.max(params.stopMin, volOf(hist) * params.stopVolMult));
}

/** Equity in USD: ETH + USDC on the sub account + spare main-wallet USDC (budget-capped) + tokens at mark. */
export function equityOf({ balances, prices, ethUsd, coins }) {
  let p = (balances.eth || 0) * ethUsd + (balances.usdc || 0) + (balances.spare || 0);
  for (const c of coins) p += (balances.tokens[c.symbol]?.amount || 0) * (prices[c.symbol] || 0);
  return p;
}

/** Daily loss cap bookkeeping. Mutates state.day; returns paused flag. */
export function dailyCap(state, equity, params, now) {
  if (!state.day || now - state.day.t >= DAY_MS || !(state.day.nav > 1)) state.day = { t: now, nav: equity };
  return state.day.nav > 1 && equity <= state.day.nav * (1 - params.dayLoss);
}

/**
 * 1) manage open positions. Returns the sells to execute (full exits in Flow) and the symbols still held.
 * @param ctx {coins, balances:{eth,usdc,spare,tokens:{sym:{raw:bigint,amount:number}}}, prices, ethUsd, flow:{sym:rawFlow}, state, params, now}
 */
export function manageExits(ctx) {
  const { coins, balances, prices, flow, state, params } = ctx;
  const now = ctx.now ?? Date.now();
  const tick = state.tick;
  const equity = equityOf(ctx);
  const paused = dailyCap(state, equity, params, now);
  const sells = [], held = [];

  for (const tok of coins) {
    const bal = balances.tokens[tok.symbol];
    const raw = bal?.raw ?? 0n;
    const amount = bal?.amount ?? 0;
    const px = prices[tok.symbol] || 0;
    const usd = amount * px;
    if (usd < 0.5) continue;
    let c = state.lots[tok.symbol];
    if (!(c && c.entry > 0)) c = state.lots[tok.symbol] = { entry: px, peak: px, opened: tick, tp1: false, tp2: false, launch: false, stop: defaultStop(params) };
    if (px > c.peak) c.peak = px;
    const l = (px - c.entry) / c.entry, p = (px - c.peak) / c.peak, m = tick - c.opened;
    const sell = (reason, tone, kind) => sells.push({ tok, raw, frac: 1, usd, pnl: l, reason, tone, kind });

    if (params.flow) {
      const F = flowScore(flow[tok.symbol]);
      if (l <= -params.stop) { sell("Down " + (Math.abs(l) * 100).toFixed(1) + "% from the entry. Stopped.", "bad", "stop"); continue; }
      if (c.peak >= c.entry * (1 + params.trailArm) && p <= -params.trail) { sell("Gave back " + (Math.abs(p) * 100).toFixed(1) + "% from the peak (+" + ((c.peak / c.entry - 1) * 100).toFixed(1) + "%). Locked the gain.", "ok", "trail"); continue; }
      if (F && F.n5 >= params.minTx5 && F.imb5 <= params.flipImb && F.c5 < 0) { sell("Flow flipped: " + Math.round(((1 - F.imb5) / 2) * 100) + "% of the last 5 minutes were sells. Out at " + (l >= 0 ? "+" : "") + (l * 100).toFixed(1) + "%.", l >= 0 ? "ok" : "bad", "flip"); continue; }
      if (m >= params.timeTicks && Math.abs(l) <= params.timeBand) { sell("Flat for " + params.timeTicks + " ticks. Time stop.", "fg", "time"); continue; }
      held.push(tok.symbol);
      continue;
    }
    if (params.classic) {
      if (l <= -params.stop) { sell("Down " + (Math.abs(l) * 100).toFixed(1) + "% from the entry. Sold.", "bad", "stop"); continue; }
      if (c.peak >= c.entry * (1 + params.trailArm) && p <= -params.trail) { sell("Gave back " + (Math.abs(p) * 100).toFixed(1) + "% from the peak (+" + ((c.peak / c.entry - 1) * 100).toFixed(1) + "%). Locked the gain.", "ok", "trail"); continue; }
      held.push(tok.symbol);
      continue;
    }
    throw new Error("Mode not implemented in the worker: only flow (and the classic exit branch) are transcribed.");
  }
  return { sells, held, equity, paused };
}

/** Called after a full sell lands (sellPart with frac >= .999). */
export function closeLot(state, symbol) {
  delete state.lots[symbol];
  delete state.ref[symbol];
  state.cool[symbol] = state.tick;
}

/** Called after a buy lands. */
export function openLot(state, symbol, price, params) {
  state.lots[symbol] = { entry: price, peak: price, opened: state.tick, tp1: false, tp2: false, launch: false, stop: params.stop };
}

/** Browser: after managing positions, drop lots for coins that are neither held nor just sold (dust / withdrawn). */
export function pruneLots(state, held, sold) {
  for (const s of Object.keys(state.lots)) if (!held.includes(s) && !sold.includes(s)) delete state.lots[s];
}

/**
 * 2) Flow entries: candidates sorted by score desc. Empty when paused.
 */
export function pickEntriesFlow({ coins, prices, flow, state, params, held, paused }) {
  const fl = [];
  if (paused) return fl;
  for (const tok of coins) {
    if (tok.launch || held.includes(tok.symbol) || !(prices[tok.symbol] > 0)) continue;
    if (state.cool[tok.symbol] !== undefined && state.tick - state.cool[tok.symbol] < params.cooldown) continue;
    const F = flowScore(flow[tok.symbol]);
    if (!F) continue;
    if (F.n5 >= params.minTx5 && F.v1 >= params.minVol1 && F.liq >= params.minLiq && F.imb5 >= params.imb5 && F.imb1 >= params.imb1 && F.accel >= params.accel && F.c5 >= params.c5 && F.c1 > 0) fl.push({ tok, F });
  }
  fl.sort((a, b) => b.F.score - a.F.score);
  return fl;
}

/**
 * Classic entries (not wired into index.js yet): reference = price when first seen, reset after a sale.
 * Transcribed so the mode can be enabled later; returns candidates sorted by move desc.
 */
export function pickEntriesClassic({ coins, prices, state, params, held }) {
  const cl = [];
  for (const tok of coins) {
    if (tok.launch) continue;
    const px = prices[tok.symbol];
    if (!(px > 0)) continue;
    if (held.includes(tok.symbol)) { delete state.ref[tok.symbol]; continue; }
    if (!(state.ref[tok.symbol] > 0)) { state.ref[tok.symbol] = px; continue; }
    const move = (px - state.ref[tok.symbol]) / state.ref[tok.symbol];
    if (move >= params.entry) cl.push({ tok, move });
  }
  cl.sort((a, b) => b.move - a.move);
  return cl;
}

export function entryNote(tok, usd, F) {
  return "USDC → " + tok.symbol + " · $" + usd.toFixed(2) + " · FLOW. " + Math.round(((1 + F.imb5) / 2) * 100) + "% buys over " + F.n5 + " trades in 5m, volume " + F.accel.toFixed(1) + "x the hourly pace, +" + F.c5.toFixed(1) + "% in 5m.";
}

/**
 * Flow entry loop, same control flow as the browser:
 *   for each candidate: stop at maxPos; clip = min(cash, equity*size); stop under LIVE_MIN_CLIP;
 *   skip (not stop) when the round trip is too thin; on a successful buy cash -= clip, held++.
 * `roundTrip(tok, units)` returns the fraction of USDC that survives buy+sell quotes (0 = no quote).
 * `buy(tok, units, usd)` performs the swap and returns a tx hash (throws on failure).
 * Returns the list of fills and notes.
 */
export async function runEntriesFlow({ candidates, cash, equity, heldCount, params, prices, state, roundTrip, buy, toUnits, note = () => {} }) {
  let s = cash, m = heldCount;
  const fills = [];
  for (const cand of candidates) {
    if (m >= params.maxPos) break;
    const usd = Math.min(s, equity * params.size);
    if (usd < LIVE_MIN_CLIP) break;
    const units = toUnits(usd, 6);
    const rt = await roundTrip(cand.tok, units);
    if (!(rt >= 1 - LIVE_MAX_ROUNDTRIP)) {
      note(cand.tok.symbol + " shows buy pressure but the pool is too thin (round trip " + (rt > 0 ? ((1 - rt) * 100).toFixed(1) + "% loss" : "no quote") + "). Skipped.", "fg");
      continue;
    }
    try {
      const tx = await buy(cand.tok, units, usd);
      const px = prices[cand.tok.symbol];
      openLot(state, cand.tok.symbol, px, params);
      s -= usd; m++;
      fills.push({ tok: cand.tok, usd, units, tx, F: cand.F, price: px });
      note(entryNote(cand.tok, usd, cand.F) + " " + String(tx).slice(0, 10) + "…", "gold");
    } catch (e) {
      note(cand.tok.symbol + " buy failed: " + (e instanceof Error ? e.message.slice(0, 80) : "swap failed"), "bad");
    }
  }
  return { fills, cash: s, heldCount: m };
}

/** Convenience for tests and dry runs: one full pure tick with a synthetic executor (every swap succeeds). */
export async function simulateTick(ctx, { roundTrip = async () => 1 } = {}) {
  const { state, params, coins, prices } = ctx;
  state.tick++;
  const notes = [];
  const note = (t, tone) => notes.push({ text: t, tone: tone || "fg" });
  const ex = manageExits(ctx);
  const sold = [];
  for (const s of ex.sells) {
    note(s.tok.symbol + " → USDC · $" + s.usd.toFixed(2) + " · " + s.reason, s.tone);
    ctx.balances.usdc += s.usd;
    delete ctx.balances.tokens[s.tok.symbol];
    closeLot(state, s.tok.symbol);
    sold.push(s.tok.symbol);
  }
  pruneLots(state, ex.held, sold);
  const cash = ctx.balances.usdc + (ctx.balances.spare || 0);
  const candidates = pickEntriesFlow({ coins, prices, flow: ctx.flow, state, params, held: ex.held, paused: ex.paused });
  const r = await runEntriesFlow({
    candidates, cash, equity: ex.equity, heldCount: ex.held.length, params, prices, state, roundTrip,
    toUnits: (usd) => BigInt(Math.round(usd * 1e6)),
    buy: async (tok, units, usd) => {
      ctx.balances.usdc -= usd;
      const amount = usd / prices[tok.symbol];
      ctx.balances.tokens[tok.symbol] = { raw: BigInt(Math.round(amount * 10 ** tok.decimals)), amount };
      return "0xsim" + tok.symbol;
    },
    note,
  });
  if (!ex.sells.length && !r.fills.length) note(ex.paused ? "Daily loss cap hit (−" + (params.dayLoss * 100).toFixed(0) + "%). No new entries until tomorrow." : "Holding " + r.heldCount + " position" + (r.heldCount === 1 ? "" : "s") + ". No coin shows buy pressure yet.");
  return { ...ex, sold, candidates, fills: r.fills, notes };
}
