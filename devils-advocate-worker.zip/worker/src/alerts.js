// Telegram alerts: fill / stop / halt / error. No-op when TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID is unset.
export function makeAlerts({ token, chatId, fetchImpl = fetch, log = console.error } = {}) {
  const on = !!(token && chatId);
  async function send(text) {
    if (!on) return false;
    try {
      const r = await fetchImpl(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ chat_id: chatId, text, disable_web_page_preview: true }),
      });
      if (!r.ok) log("telegram " + r.status);
      return r.ok;
    } catch (e) {
      log("telegram failed: " + (e?.message || e));
      return false;
    }
  }
  const tag = (kind) => ({ fill: "FILL", stop: "STOP", halt: "HALT", error: "ERROR", info: "INFO" }[kind] || kind.toUpperCase());
  return {
    enabled: on,
    send,
    fill: (text) => send(`[${tag("fill")}] ${text}`),
    stop: (text) => send(`[${tag("stop")}] ${text}`),
    halt: (text) => send(`[${tag("halt")}] ${text}`),
    error: (text) => send(`[${tag("error")}] ${text}`),
    info: (text) => send(`[${tag("info")}] ${text}`),
  };
}
