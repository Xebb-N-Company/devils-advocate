#!/usr/bin/env node
// Devil's Advocate worker: the live tick (VQ) running server-side, 24/7.
//
//   DRY_RUN=1 (default): reads prices, flow and balances for real, makes the same decisions as the
//   browser, prints the exact JSON-RPC bodies it WOULD send to the Coinbase wallet RPC, and never POSTs
//   there. DRY_RUN=0: signs user operations with OWNER_PRIVATE_KEY and sends them for real.
import { loadConfig } from "./config.js";
import { buildParams, riskLabel } from "./params.js";
import { allCoins, makeClient, readBalances, priceBook, roundTrip, buySteps, sellSteps, toUnits, toNum, balanceOf, USDC } from "./chain.js";
import { manageExits, pickEntriesFlow, runEntriesFlow, closeLot, pruneLots } from "./strategy.js";
import { flowScore } from "./flow.js";
import { makeCoinbase, ownerFromKey, prepareCallsRequest } from "./coinbase.js";
import { makeAlerts } from "./alerts.js";
import { loadState, saveState, makeSupabase } from "./store.js";

const json = (v) => JSON.stringify(v, (_, x) => (typeof x === "bigint" ? x.toString() : x), 2);
const ts = () => new Date().toISOString().slice(11, 19);
const log = (...a) => console.log(ts(), ...a);

export async function main(env = process.env) {
  const cfg = loadConfig(env);
  const params = buildParams(cfg.mode, cfg.risk);
  if (!params.flow) throw new Error(`MODE=${cfg.mode} is not implemented in the worker yet (only flow). See strategy.js pickEntriesClassic for the Classic slot.`);
  const coins = allCoins();
  const client = makeClient(cfg.rpcUrl);
  const alerts = makeAlerts(cfg.telegram);
  const db = makeSupabase({ ...cfg.supabase, desk: cfg.deskName || cfg.subAccount });
  const state = loadState(cfg.stateFile);
  const paperUsdc = cfg.dryRun ? Number(env.PAPER_USDC || 0) : 0;

  const owner = cfg.ownerPrivateKey ? ownerFromKey(cfg.ownerPrivateKey) : null;
  const cb = !cfg.dryRun ? makeCoinbase({ owner, subAccount: cfg.subAccount, mainAccount: cfg.mainAccount, paymasterUrl: cfg.paymasterUrl, rpcUrl: cfg.coinbaseRpcUrl, log: (...a) => log("coinbase", ...a) }) : null;

  log(`Devil's Advocate worker · ${cfg.dryRun ? "DRY_RUN (nothing is sent)" : "LIVE"} · mode=${cfg.mode} risk=${cfg.risk} (${riskLabel(cfg.risk)}) · tick=${cfg.tickSeconds}s`);
  log(`sub account ${cfg.subAccount}${cfg.mainAccount ? " · main wallet " + cfg.mainAccount + " · budget $" + cfg.budgetUsdc : " · no main wallet (no spend permission funding)"}${owner ? " · owner " + owner.address : ""}${cfg.paymasterUrl ? " · paymaster on" : ""}`);
  log(`params: size ${(params.size * 100).toFixed(0)}% · max ${params.maxPos} · stop ${(params.stop * 100).toFixed(1)}% · trail ${(params.trail * 100).toFixed(0)}% armed at ${(params.trailArm * 100).toFixed(0)}% · imb5 ≥ ${params.imb5.toFixed(2)} · minTx5 ${params.minTx5} · accel ≥ ${params.accel.toFixed(2)} · time stop ${params.timeTicks} ticks · cooldown ${params.cooldown} · day cap ${(params.dayLoss * 100).toFixed(0)}%`);
  log(`book: ${coins.length} coins · telegram ${alerts.enabled ? "on" : "off"} · supabase ${db.enabled ? "on" : "off"} · state ${cfg.stateFile}`);

  /** Send one atomic batch from the sub account (or print it in DRY_RUN). Returns a tx hash. */
  async function sendBatch(label, calls) {
    const req = prepareCallsRequest({ calls, subAccount: cfg.subAccount, mainAccount: cfg.mainAccount, paymasterUrl: cfg.paymasterUrl });
    if (cfg.dryRun) {
      log(`DRY_RUN would POST ${cfg.coinbaseRpcUrl} ← ${label}`);
      console.log(json({ jsonrpc: "2.0", method: req.method, params: req.params }));
      console.log("  then: owner.sign(hexToString(signatureRequest.hash)) → wallet_sendPreparedCalls {signature:{type:'secp256k1',data:{address,signature}}} → wallet_getCallsStatus until 200");
      return "0xdryrun" + Date.now().toString(16);
    }
    return cb.sendCalls(calls);
  }
  /** Run the steps of a buy or sell (1 or 2 atomic batches); returns the last tx hash. */
  async function runSteps(steps) {
    let tx = "", prevOut;
    for (const st of steps) {
      if (st.before) await st.before();
      const plan = await st.plan(cfg.dryRun ? { dryOut: prevOut } : {});
      tx = await sendBatch(st.label + (plan.out !== undefined ? ` (quote out ${plan.out})` : ""), plan.calls);
      prevOut = plan.out;
    }
    return tx;
  }

  let prevPrices = state.prices || {};
  let lastPaused = false;

  async function tick() {
    state.tick++;
    const now = Date.now();
    const notes = [];
    const note = (t, tone = "fg") => { notes.push({ t, tone }); log(`[${tone}] ${t}`); };

    const { prices, flow, ethUsd } = await priceBook(client, { prevPrices });
    if (!(ethUsd > 0)) { note("No ETH price from the Base pool. Holding."); return; }
    prevPrices = prices; state.prices = prices;

    const bal = await readBalances(client, cfg.subAccount, coins, cfg.mainAccount);
    if (paperUsdc > 0) bal.usdc += paperUsdc;
    const spare = cfg.mainAccount ? Math.max(0, Math.min(bal.mainUsdc, cfg.budgetUsdc)) : 0;
    const balances = { eth: bal.eth, usdc: bal.usdc, spare, tokens: bal.tokens };
    const priced = Object.values(prices).filter((p) => p > 0).length;
    const flowed = Object.keys(flow).length;
    log(`tick ${state.tick} · ETH $${ethUsd.toFixed(2)} · ${priced}/${coins.length} priced · ${flowed} with flow · sub: ${bal.eth.toFixed(5)} ETH, $${bal.usdc.toFixed(2)} USDC${paperUsdc ? " (incl. PAPER_USDC " + paperUsdc + ")" : ""}${cfg.mainAccount ? ` · main $${bal.mainUsdc.toFixed(2)} → spare $${spare.toFixed(2)}` : ""}`);

    // 1) manage open positions
    const ex = manageExits({ coins, balances, prices, ethUsd, flow, state, params, now });
    const held = ex.held, sold = [];
    for (const s of ex.sells) {
      try {
        const tx = await runSteps(sellSteps(client, s.tok, s.raw, cfg.subAccount));
        note(`${s.tok.symbol} → USDC · $${s.usd.toFixed(2)} · ${s.reason} ${tx.slice(0, 10)}…`, s.tone);
        closeLot(state, s.tok.symbol); sold.push(s.tok.symbol);
        const msg = `${s.tok.symbol} → USDC $${s.usd.toFixed(2)} (${s.pnl >= 0 ? "+" : ""}${(s.pnl * 100).toFixed(1)}%) · ${s.reason} · ${tx}`;
        if (s.kind === "stop") await alerts.stop(msg); else await alerts.fill(msg);
        await db.fill({ side: "sell", symbol: s.tok.symbol, usd: s.usd, note: s.reason, tx, mode: cfg.mode, risk: cfg.risk });
      } catch (e) {
        // Deliberate deviation from the browser: a failed sell keeps its lot so the stop is retried next tick
        // (the browser drops the lot and re-marks the entry at the current price).
        note(`${s.tok.symbol} sell failed: ${(e?.message || "swap failed").slice(0, 80)}`, "bad");
        held.push(s.tok.symbol);
        await alerts.error(`${s.tok.symbol} sell failed: ${(e?.message || "swap failed").slice(0, 200)}`);
      }
    }
    pruneLots(state, held, sold);

    // 2) entries
    let usdc = bal.usdc;
    if (sold.length && !cfg.dryRun) usdc = toNum(await balanceOf(client, USDC, cfg.subAccount), 6);
    const cash = usdc + spare;
    const candidates = pickEntriesFlow({ coins, prices, flow, state, params, held, paused: ex.paused });
    if (cfg.dryRun && env.DRY_FORCE_BUY) {
      // DRY_RUN only: pretend these symbols show buy pressure so the exact call batches get printed.
      for (const sym of env.DRY_FORCE_BUY.split(",").map((s) => s.trim()).filter(Boolean)) {
        const tok = coins.find((c) => c.symbol.toLowerCase() === sym.toLowerCase());
        if (!tok) { note(`DRY_FORCE_BUY: unknown symbol ${sym}`, "bad"); continue; }
        if (held.includes(tok.symbol)) { note(`DRY_FORCE_BUY: ${tok.symbol} already held`, "fg"); continue; }
        const F = flowScore(flow[tok.symbol]) || { imb5: 0, imb1: 0, accel: 0, n5: 0, n1: 0, v1: 0, liq: 0, c5: 0, c1: 0, score: 0 };
        candidates.push({ tok, F, forced: true });
        note(`DRY_FORCE_BUY: injecting ${tok.symbol} as a candidate (synthetic, DRY_RUN only)`, "gold");
      }
    }
    if (candidates.length) log(`candidates: ${candidates.map((c) => `${c.tok.symbol}(score ${c.F.score.toFixed(2)}, imb5 ${c.F.imb5.toFixed(2)}, accel ${c.F.accel.toFixed(1)}x, n5 ${c.F.n5}, +${c.F.c5.toFixed(1)}%)`).join(" · ")}`);
    const r = await runEntriesFlow({
      candidates, cash, equity: ex.equity, heldCount: held.length, params, prices, state,
      toUnits,
      roundTrip: (tok, units) => roundTrip(client, tok, units),
      buy: async (tok, units, usd) => {
        const tx = await runSteps(buySteps(client, tok, units, cfg.subAccount));
        await alerts.fill(`USDC → ${tok.symbol} $${usd.toFixed(2)} · FLOW · ${tx}`);
        await db.fill({ side: "buy", symbol: tok.symbol, usd, note: "FLOW", tx, mode: cfg.mode, risk: cfg.risk });
        return tx;
      },
      note,
    });

    if (!ex.sells.length && !r.fills.length) note(ex.paused ? `Daily loss cap hit (−${(params.dayLoss * 100).toFixed(0)}%). No new entries until tomorrow.` : `Holding ${r.heldCount} position${r.heldCount === 1 ? "" : "s"}. No coin shows buy pressure yet.`);
    if (ex.paused && !lastPaused) await alerts.halt(`Daily loss cap hit (−${(params.dayLoss * 100).toFixed(0)}%). NAV $${ex.equity.toFixed(2)} vs day start $${state.day.nav.toFixed(2)}. No new entries until tomorrow.`);
    lastPaused = ex.paused;

    // NAV / PnL record
    if (!(state.basis > 0) && ex.equity > 0) state.basis = ex.equity;
    const pnl = ex.equity - (state.basis || ex.equity);
    log(`equity $${ex.equity.toFixed(2)} · pnl ${pnl >= 0 ? "+" : ""}$${pnl.toFixed(2)} · held ${held.join(", ") || "—"} · lots ${Object.keys(state.lots).join(", ") || "—"}${ex.paused ? " · PAUSED (day cap)" : ""}`);
    await db.pnl({ nav: ex.equity, pnl });
    saveState(cfg.stateFile, state);
  }

  let stop = false;
  process.on("SIGINT", () => { stop = true; log("SIGINT: finishing tick then exiting"); });
  process.on("SIGTERM", () => { stop = true; log("SIGTERM: finishing tick then exiting"); });

  for (;;) {
    const started = Date.now();
    try {
      await tick();
    } catch (e) {
      log("[bad] tick failed: " + (e?.stack || e));
      await alerts.error(`tick failed: ${(e?.message || e).toString().slice(0, 300)}`);
      try { saveState(cfg.stateFile, state); } catch { /* ignore */ }
    }
    if (cfg.once || stop) break;
    const wait = Math.max(1000, cfg.tickSeconds * 1000 - (Date.now() - started));
    await new Promise((r) => setTimeout(r, wait));
    if (stop) break;
  }
}

if (process.argv[1] && import.meta.url === new URL("file://" + process.argv[1]).href) {
  main().catch((e) => { console.error(e); process.exit(1); });
}
