// Strategy parameters, copied faithfully from the site bundle (routes-*.js):
// KEEL_COMMON, KEEL_MODES, riskScale, riskLabel. Do not "improve" these; the worker
// must make the same decisions as the browser for the same MODE and RISK.

export const KEEL_COMMON = {
  tpFrac: 1 / 3, breakeven: 0.01, histLen: 70,
  launchStop: 0.20, launchTp: 0.40, launchTrail: 0.20, launchTime: 30, launchConfirm: 0.20, launchWindow: 30, launchSize: 0.10, maxLaunch: 2,
};

export const KEEL_MODES = {
  // Flow (default): order-flow strategy. Buy when buys dominate sells over the last 5 minutes and the hour,
  // 5-minute volume is running well above the hourly pace, and price is already moving up.
  // Exit on a stop, a trail, or when the flow flips to selling.
  flow: {
    flow: true, imb5: 0.3, imb1: 0.1, accel: 1.5, minTx5: 8, minVol1: 2e4, minLiq: 1e5, c5: 0.5,
    size: 0.25, maxPos: 4, stop: 0.06, trailArm: 0.06, trail: 0.04, flipImb: -0.3, timeTicks: 45, timeBand: 0.02,
    cooldown: 10, dayLoss: 0.25, look: 6, lookMin: 3, breadthMin: 0, stopMin: 0.06, stopMax: 0.06, stopVolMult: 0,
    tp1: 9, tp2: 9, trail1: 0.04, trail2: 0.04, entryVolMult: 0, feeMult: 0, entry: 0.005,
  },
  // Classic: reference = price when the coin was first seen (reset after a sale). Up 2.5% = buy, full cash split, -2.5% stop.
  classic: {
    classic: true, entry: 0.025, stop: 0.025, trailArm: 1e9, trail: 0.05, look: 6, lookMin: 3, breadthMin: 0, size: 1, maxPos: 999,
    stopMin: 0.025, stopMax: 0.025, stopVolMult: 0, tp1: 9, tp2: 9, trail1: 0.05, trail2: 0.05, timeTicks: 1e9, timeBand: 0,
    cooldown: 0, dayLoss: 1, entryVolMult: 0, feeMult: 0,
  },
  // Five/Ten: up 5% from the reference = buy, full cash split, -10% stop, 5% trail once up 10%.
  fiveten: {
    classic: true, entry: 0.05, stop: 0.10, trailArm: 0.10, trail: 0.05, look: 6, lookMin: 3, breadthMin: 0, size: 1, maxPos: 999,
    stopMin: 0.10, stopMax: 0.10, stopVolMult: 0, tp1: 9, tp2: 9, trail1: 0.05, trail2: 0.05, timeTicks: 1e9, timeBand: 0,
    cooldown: 0, dayLoss: 1, entryVolMult: 0, feeMult: 0,
  },
  inferno: {
    entry: 0.03, entryVolMult: 2, feeMult: 1.5, look: 30, lookMin: 15, breadthMin: 0, size: 1 / 3, maxPos: 3,
    stopMin: 0.04, stopMax: 0.10, stopVolMult: 4, tp1: 0.05, tp2: 0.125, trail1: 0.05, trail2: 0.03, timeTicks: 60, timeBand: 0.015,
    cooldown: 10, dayLoss: 0.25,
  },
  devil: {
    entry: 0.05, entryVolMult: 3, feeMult: 3, look: 60, lookMin: 30, breadthMin: 0.4, size: 1 / 3, maxPos: 3,
    stopMin: 0.08, stopMax: 0.20, stopVolMult: 5, tp1: 0.12, tp2: 0.30, trail1: 0.05, trail2: 0.03, timeTicks: 150, timeBand: 0.02,
    cooldown: 24, dayLoss: 0.20,
  },
};

// Risk dial: 0 = cautious, 50 = the mode as designed, 100 = reckless. `t` is risk/100.
export function riskScale(e, t) {
  const n = Math.min(1, Math.max(0, t)), r = 0.5 + n, i = 1.5 - n, a = { ...e };
  if (a.size !== undefined) a.size = Math.min(1, Math.max(0.05, e.size * r));
  if (a.maxPos !== undefined && e.maxPos < 50) a.maxPos = Math.max(1, Math.round(e.maxPos * r));
  if (a.dayLoss !== undefined) a.dayLoss = Math.min(0.6, Math.max(0.05, e.dayLoss * r));
  for (const k of ["imb5", "imb1", "accel", "c5", "entry", "minVol1", "minLiq", "breadthMin", "feeMult", "entryVolMult"]) if (a[k] !== undefined) a[k] = e[k] * i;
  if (a.minTx5 !== undefined) a.minTx5 = Math.max(2, Math.round(e.minTx5 * i));
  if (a.cooldown !== undefined) a.cooldown = Math.max(1, Math.round(e.cooldown * i));
  for (const k of ["stop", "stopMin", "stopMax", "launchStop"]) if (a[k] !== undefined && e[k] < 1) a[k] = Math.min(0.5, e[k] * r);
  return a;
}

export function riskLabel(e) {
  return e < 20 ? "Cautious" : e < 40 ? "Careful" : e < 60 ? "Balanced" : e < 80 ? "Aggressive" : "Reckless";
}

// Same as the browser's applyParams(): riskScale(Object.assign({}, KEEL_COMMON, KEEL_MODES[mode]), risk/100)
export function buildParams(mode = "flow", risk = 50) {
  if (!KEEL_MODES[mode]) throw new Error("Unknown mode " + mode);
  return riskScale(Object.assign({}, KEEL_COMMON, KEEL_MODES[mode]), risk / 100);
}

// Fixed live-desk constants from the bundle.
export const LIVE_MIN_CLIP = 1;          // smallest clip in USD
export const LIVE_MAX_ROUNDTRIP = 0.06;  // skip a coin if buy+sell quotes lose more than 6%
