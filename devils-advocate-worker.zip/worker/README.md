# Devil's Advocate · 24/7 worker

A headless, server-side copy of the Devil's Advocate agentic trading desk. The browser desk only trades while the tab is open; this worker runs the same Flow strategy every tick (default 60 s) from a server, trading the **same Base Account sub account** the site created, so the bot keeps working when you close the laptop.

- Node 20+, ESM, [viem](https://viem.sh). No framework, no database required.
- Same book (55 Uniswap V3 coins + 26 aggregator coins, extracted from the site bundle, not hand-typed), same thresholds, sizing, stops, trail, flow-flip exit, 45-tick time stop, cooldown, daily loss cap and max positions, parameterised by `MODE` and `RISK` exactly like the site.
- Signs with its own **owner key** that you add to the sub account from the site; the sub account draws USDC from your main wallet through the **spend permission** you grant once in the browser.
- **`DRY_RUN=1` by default**: it prices the book, runs the strategy and prints the exact Coinbase RPC calls it *would* send, but never POSTs to the Coinbase wallet RPC.

> **Warning.** The owner key in `OWNER_PRIVATE_KEY` is an owner of the sub account: whoever has it can move everything the sub account holds and everything the spend permission allows it to pull from your main wallet. Keep it in a secret store, never commit `.env`, and keep the spend permission and `BUDGET_USDC` small. This is experimental software trading meme coins; you can lose the whole budget.

## What it does each tick

1. Prices every coin in the book: V3 coins via Uniswap QuoterV2 (a ~$5 probe), aggregator coins via DexScreener, plus 5-minute / 1-hour buy-sell flow for all of them from DexScreener.
2. Reads the sub account's ETH, USDC and token balances (one multicall), and the main wallet's USDC (capped by `BUDGET_USDC`) when a spend permission is configured.
3. **Exits** (Flow): stop at −6 % from entry · trailing stop 4 % off the peak once up 6 % · flow flip (≥ minTx5 trades in 5 m, ≥ 65 % sells, price down in 5 m) · time stop after 45 ticks if within ±2 % · the daily loss cap (−25 % of the day's starting NAV) pauses new entries but still lets exits run.
4. **Entries** (Flow): candidates need `n5 ≥ 8`, 1-hour volume ≥ $20 k, liquidity ≥ $100 k, 5-m buy imbalance ≥ 0.30, 1-h imbalance ≥ 0.10, 5-m volume ≥ 1.5× the hourly pace, +0.5 % in 5 m and up in 1 h; sorted by `imb5 × min(accel, 4)`. Each buy is 25 % of equity, max 4 positions, minimum clip $1, skipped if the quoted round trip would lose more than 6 %.
5. Every swap is one **atomic batch** (`approve` + swap when the allowance is short; two batches for WETH-routed coins, as in the browser) sent through `wallet_prepareCalls → sign → wallet_sendPreparedCalls → wallet_getCallsStatus`.
6. Persists lots, peaks, cooldowns and the daily NAV to `STATE_FILE`; optional Telegram alerts and Supabase rows.

Those numbers are for Risk 50. `RISK` scales them exactly like the site: Risk 90 → 35 % size, max 6, stop 8.4 %, imbalance 0.18 (59 % buys), minTx5 5, accel 0.9; Risk 10 → 15 % size, max 2, stop 3.6 %, imbalance 0.42, minTx5 11, accel 2.1. `npm run tick:dry` prints the effective parameters.

Only **Flow** is implemented. `strategy.js` has a Classic slot (entry +X % from the first-seen reference, stop X %) and `params.js` carries every mode's numbers, but `MODE=classic` is not wired to entries yet.

## Setup

### 1. Install

```bash
cd worker
npm ci
npm test            # unit tests (no network)
npm run tick:dry    # one real DRY_RUN tick against DexScreener + Base with a throwaway sub account
```

### 2. Generate the worker's owner key

```bash
npm run keygen
```

Prints an address and a private key. Put the private key in `OWNER_PRIVATE_KEY`. Treat it like cash.

### 3. Add that address as an owner of the sub account (on the site)

Open the Devil's Advocate desk in the browser, connect the Base Account that created the desk, and add the address from step 2 as an owner of the desk's sub account (the sub account is an ERC-4337 smart account; the site performs the add-owner call through the Base Account SDK and it is confirmed with your passkey). Copy the sub account address into `SUB_ACCOUNT` and your main Base Account into `MAIN_ACCOUNT`.

### 4. Fund

Send USDC (the budget) and a little ETH (≈ 0.001 ETH covers many swaps on Base) to the **main** Base Account. The sub account pulls USDC through the spend permission; ETH for gas comes either from the sub account's own balance or from an optional paymaster (`PAYMASTER_URL`).

### 5. Grant the spend permission once (on the site)

Make the first trade from the browser desk. The Base Account popup asks you to grant the sub account a USDC spend permission from your main wallet. The worker reuses that permission via the `funding: [{ type: "spendPermission", autoApply: true, sources: [MAIN_ACCOUNT] }]` capability on every prepared batch. The worker cannot ask for it itself: granting needs your passkey in the browser.

### 6. Configure

```bash
cp .env.example .env     # then edit
```

| Variable | Default | Meaning |
| --- | --- | --- |
| `DRY_RUN` | `1` | `1` = never send; print the exact RPC bodies. `0` = trade for real. |
| `OWNER_PRIVATE_KEY` | — | Worker owner key. Required when `DRY_RUN=0`. |
| `SUB_ACCOUNT` | — | The desk's sub account. Always required. |
| `MAIN_ACCOUNT` | — | Your main Base Account (spend-permission source). Required when `DRY_RUN=0`. |
| `BUDGET_USDC` | `25` | Max main-wallet USDC the desk may draw; counts toward cash and equity. |
| `MODE` | `flow` | Strategy. Only `flow` trades. |
| `RISK` | `50` | 0..100 risk dial, same scaling as the site. |
| `TICK_SECONDS` | `60` | Loop interval. |
| `PAYMASTER_URL` | — | Optional ERC-7677 paymaster; sent as `capabilities.paymasterService`. |
| `TELEGRAM_BOT_TOKEN` / `TELEGRAM_CHAT_ID` | — | Optional alerts for fills, stops, halts, errors. |
| `SUPABASE_URL` / `SUPABASE_SERVICE_KEY` | — | Optional logging into `da_fills` / `da_pnl`. The Devil's Advocate project already has these tables with insert-only public access, so the publishable key in `.env.example` works; `supabase.sql` is only for a fresh project. |
| `STATE_FILE` | `./state.json` | Lots, peaks, cooldowns, daily NAV. |
| `BASE_RPC_URL` | publicnode | Base JSON-RPC for reads. |
| `COINBASE_RPC_URL` | `https://rpc.wallet.coinbase.com` | Coinbase wallet RPC used for prepare / send / status. |
| `DESK_NAME`, `ONCE` | — | Label for logs and Supabase; `ONCE=1` runs one tick and exits. |

### 7. Run

```bash
# dry first, with your real sub account, to see what it would do
DRY_RUN=1 node src/index.js

# then for real
DRY_RUN=0 node src/index.js
```

Stop it with Ctrl-C / SIGTERM; it finishes the current tick and saves state.

## What DRY_RUN means

With `DRY_RUN=1` (the default) the worker does everything except send: it fetches real prices and flow, reads real balances, runs the strategy, quotes the round trip, builds the `approve` + swap calldata, and logs the complete `wallet_prepareCalls` JSON body including the funding / paymaster capabilities, then records the "fill" in its local state with a fake `0xdryrun…` hash. No request ever goes to `COINBASE_RPC_URL`, nothing is signed, and `OWNER_PRIVATE_KEY` / `MAIN_ACCOUNT` are optional. Two helpers exist only in dry mode: `PAPER_USDC=25` adds pretend USDC so an empty sub account can "buy", and `DRY_FORCE_BUY=AERO,DENIM` injects synthetic candidates so you can see the buy path end to end. Because the first leg of a WETH-routed buy never lands in dry mode, the second leg uses the first leg's quote.

## Deploying

### Docker (any VPS, Railway, Fly)

```bash
docker build -t da-worker .
docker run -d --name da --restart unless-stopped --env-file .env -v da-state:/data da-worker
docker logs -f da
```

The image stores state in the `/data` volume (`STATE_FILE=/data/state.json`).

**Railway**: new project → Deploy from repo, root directory `worker`. Railway detects the Dockerfile. Add the variables from `.env.example` under *Variables* (`DRY_RUN=0` only when you are ready), add a volume mounted at `/data`, and keep one replica. There is no HTTP port; disable the public domain.

**Fly.io**:

```bash
fly launch --no-deploy --dockerfile Dockerfile --name da-worker   # answer "no" to Postgres/Redis
fly volumes create da_state --size 1
fly secrets set OWNER_PRIVATE_KEY=0x… SUB_ACCOUNT=0x… MAIN_ACCOUNT=0x… DRY_RUN=0
fly deploy
```

In `fly.toml` add `[mounts] source = "da_state" destination = "/data"`, remove the `[http_service]` block, and keep `min_machines_running = 1` with a single machine.

### VPS with systemd

```bash
sudo useradd -r -m -s /usr/sbin/nologin da
sudo -u da git clone <repo> /home/da/xebb-grok && cd /home/da/xebb-grok/worker && sudo -u da npm ci --omit=dev
sudo install -m 600 -o da .env /home/da/xebb-grok/worker/.env
```

`/etc/systemd/system/da-worker.service`:

```ini
[Unit]
Description=Devil's Advocate worker
After=network-online.target
Wants=network-online.target

[Service]
User=da
WorkingDirectory=/home/da/xebb-grok/worker
EnvironmentFile=/home/da/xebb-grok/worker/.env
Environment=STATE_FILE=/home/da/xebb-grok/worker/state.json
ExecStart=/usr/bin/node src/index.js
Restart=always
RestartSec=10
KillSignal=SIGTERM
TimeoutStopSec=120

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload && sudo systemctl enable --now da-worker
journalctl -u da-worker -f
```

Run **one** worker per sub account. Two workers (or a worker plus the browser desk trading at the same time) share the same balances and will double-enter.

## How signing works

The worker reproduces what `@base-org/account` 2.6.0 does for `wallet_sendCalls` from a sub account:

1. `wallet_prepareCalls` `[{ version: "1.0", calls, chainId: "0x2105", from: SUB_ACCOUNT, capabilities }]` where `capabilities.funding = [{ type: "spendPermission", data: { autoApply: true, sources: [MAIN_ACCOUNT], preference: "PREFER_DIRECT_BALANCE" } }]` and, when `PAYMASTER_URL` is set, `capabilities.paymasterService = { url }`. The SDK only adds an `attribution` suffix when the dapp configured `preference.attribution`; the site does not, so none is added.
2. Decode `signatureRequest.hash` (the SDK runs it through `hexToString`) and sign the raw 32-byte hash with the owner key: `account.sign({ hash })`, no EIP-191 prefix.
3. `wallet_sendPreparedCalls` `[{ version: "1.0", type, data: userOp, chainId, signature: { type: "secp256k1", data: { address: ownerAddress, signature } } }]` → `[callsId]`.
4. Poll `wallet_getCallsStatus [callsId]` every 2 s until `status` 200 (`receipts[0].transactionHash`) or ≥ 400 (failed).

Requests carry the SDK's `X-Cbw-Sdk-Version` / `X-Cbw-Sdk-Platform` headers. See `src/coinbase.js` and `test/coinbase.test.js`.

## Files

```
src/index.js      main loop: tick, exits, entries, alerts, state, DRY_RUN printing
src/strategy.js   pure strategy (entries, exits, cooldown, daily cap, sizing); Classic slot
src/params.js     mode numbers + riskScale, identical to the site
src/flow.js       DexScreener prices + buy/sell flow, flowScore
src/chain.js      viem reads, QuoterV2 quotes, Uniswap V3 / KyberSwap swap calldata, round trips
src/coinbase.js   prepare → sign → send → status against the Coinbase wallet RPC
src/config.js     env → config (defaults listed above)
src/alerts.js     Telegram
src/store.js      state.json + optional Supabase
src/keygen.js     owner key generator
src/book.json     coin book extracted from the site bundle (npm run book)
scripts/extract-book.js
supabase.sql      da_fills / da_pnl + RLS (anon SELECT; inserts only with the service key)
test/             vitest: strategy, params, coinbase (mocked fetch), book, config, live DRY_RUN tick
```

## Known differences from the browser desk

- A failed **sell** keeps its lot so the stop is retried next tick (the browser drops the lot).
- The browser auto-converts stray ETH to USDC on some desks; the worker never touches the sub account's ETH beyond gas.
- The Coinbase RPC endpoint is fixed to `COINBASE_RPC_URL`; the browser SDK uses the per-chain RPC URL returned during the wallet handshake. If prepare calls are rejected, set `COINBASE_RPC_URL` to the URL seen in the browser's network tab.
