import { describe, it, expect } from "vitest";
import { privateKeyToAccount } from "viem/accounts";
import { keccak256, stringToHex, toHex, recoverAddress, isHex } from "viem";
import { makeCoinbase, prepareCallsRequest, buildCapabilities, hashToSign, signatureEnvelope, serializeCall, CHAIN_ID_HEX, SDK_VERSION, SDK_PLATFORM } from "../src/coinbase.js";

// Throwaway test key (never funded).
const PK = "0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d";
const owner = privateKeyToAccount(PK);
const SUB = "0x00000000000000000000000000000000000000a1";
const MAIN = "0x000000000000000000000000000000000000dead";
const USDC = "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913";
const ROUTER = "0x2626664c2603336e57b271c5c0b26f421741e481";
const calls = [{ to: USDC, data: "0x095ea7b3" }, { to: ROUTER, data: "0x04e45aaf", value: 0n }];
const HASH = keccak256(stringToHex("user op"));

/** A mock Coinbase RPC: records every request, returns canned results, and fails the status N times first. */
function mockRpc({ pendingPolls = 1, finalStatus = 200, hashEncoding = "utf8" } = {}) {
  const requests = [];
  let polls = 0;
  const fetchImpl = async (url, init) => {
    const body = JSON.parse(init.body);
    requests.push({ url, headers: init.headers, body });
    let result;
    if (body.method === "wallet_prepareCalls") {
      result = { type: "user-operation-v8", userOp: { sender: SUB, nonce: "0x1", callData: "0xdead" }, chainId: CHAIN_ID_HEX, signatureRequest: { hash: hashEncoding === "utf8" ? stringToHex(HASH) : HASH } };
    } else if (body.method === "wallet_sendPreparedCalls") {
      result = ["0xcall5id"];
    } else if (body.method === "wallet_getCallsStatus") {
      polls++;
      result = polls <= pendingPolls ? { status: 100 } : { status: finalStatus, receipts: finalStatus === 200 ? [{ transactionHash: "0xtx" }] : [] };
    }
    return { json: async () => ({ jsonrpc: "2.0", id: body.id, result }) };
  };
  return { requests, fetchImpl };
}

describe("request shapes", () => {
  it("serializes calls with hex value and default data", () => {
    expect(serializeCall({ to: USDC })).toEqual({ to: USDC, data: "0x", value: "0x0" });
    expect(serializeCall({ to: USDC, data: "0x01", value: 5n })).toEqual({ to: USDC, data: "0x01", value: "0x5" });
  });
  it("funding capability points at the main wallet; paymasterService only when configured", () => {
    expect(buildCapabilities({ mainAccount: MAIN })).toEqual({
      funding: [{ type: "spendPermission", data: { autoApply: true, sources: [MAIN], preference: "PREFER_DIRECT_BALANCE" } }],
    });
    expect(buildCapabilities({ mainAccount: MAIN, paymasterUrl: "https://pm.example" }).paymasterService).toEqual({ url: "https://pm.example" });
    expect(buildCapabilities({})).toEqual({});
  });
  it("wallet_prepareCalls params: version 1.0, Base chain id, from = sub account", () => {
    const req = prepareCallsRequest({ calls, subAccount: SUB, mainAccount: MAIN });
    expect(req.method).toBe("wallet_prepareCalls");
    expect(req.params).toHaveLength(1);
    const p = req.params[0];
    expect(p.version).toBe("1.0"); expect(p.chainId).toBe("0x2105"); expect(p.from).toBe(SUB);
    expect(p.calls).toEqual([{ to: USDC, data: "0x095ea7b3", value: "0x0" }, { to: ROUTER, data: "0x04e45aaf", value: "0x0" }]);
    expect(p.capabilities.funding[0].data.sources).toEqual([MAIN]);
    expect(p.capabilities.attribution).toBeUndefined(); // the site sets no preference.attribution
  });
  it("hashToSign decodes the SDK's hex-encoded UTF-8 hash and accepts a bare hash", () => {
    expect(hashToSign(stringToHex(HASH))).toBe(HASH);
    expect(hashToSign(HASH)).toBe(HASH);
    expect(() => hashToSign("0x1234")).toThrow(/Unexpected signatureRequest.hash/);
    expect(() => hashToSign(undefined)).toThrow(/missing/);
  });
  it("signature envelope is { type: secp256k1, data: { address, signature } }", () => {
    expect(signatureEnvelope(owner, "0xsig")).toEqual({ type: "secp256k1", data: { address: owner.address, signature: "0xsig" } });
  });
});

describe("prepare → sign → send → status against a mocked fetch", () => {
  it("runs the full flow and returns the transaction hash", async () => {
    const { requests, fetchImpl } = mockRpc({ pendingPolls: 2 });
    const sleeps = [];
    const cb = makeCoinbase({ owner, subAccount: SUB, mainAccount: MAIN, rpcUrl: "https://rpc.test", fetchImpl, sleep: async (ms) => sleeps.push(ms) });
    const tx = await cb.sendCalls(calls);
    expect(tx).toBe("0xtx");
    expect(requests.map((r) => r.body.method)).toEqual(["wallet_prepareCalls", "wallet_sendPreparedCalls", "wallet_getCallsStatus", "wallet_getCallsStatus", "wallet_getCallsStatus"]);
    expect(sleeps).toEqual([2000, 2000]);
    for (const r of requests) {
      expect(r.url).toBe("https://rpc.test");
      expect(r.headers["X-Cbw-Sdk-Version"]).toBe(SDK_VERSION); expect(r.headers["X-Cbw-Sdk-Platform"]).toBe(SDK_PLATFORM);
      expect(r.body.jsonrpc).toBe("2.0"); expect(typeof r.body.id).toBe("number");
    }
    expect(requests[0].body.id).toBe(1); expect(requests[4].body.id).toBe(5);
    expect(requests[0].body.params[0].from).toBe(SUB);
    expect(requests[0].body.params[0].capabilities.paymasterService).toBeUndefined();
    expect(requests[2].body.params).toEqual(["0xcall5id"]);

    // sendPreparedCalls envelope: forwards type/userOp/chainId and signs the DECODED hash with the raw owner key
    const sp = requests[1].body.params[0];
    expect(sp.version).toBe("1.0"); expect(sp.type).toBe("user-operation-v8"); expect(sp.chainId).toBe("0x2105");
    expect(sp.data).toEqual({ sender: SUB, nonce: "0x1", callData: "0xdead" });
    expect(sp.signature.type).toBe("secp256k1"); expect(sp.signature.data.address).toBe(owner.address);
    expect(isHex(sp.signature.data.signature)).toBe(true); expect(sp.signature.data.signature.length).toBe(132);
    expect(await recoverAddress({ hash: HASH, signature: sp.signature.data.signature })).toBe(owner.address);
    expect(sp.signature.data.signature).toBe(await owner.sign({ hash: HASH }));
  });
  it("accepts a bare 32-byte hash too", async () => {
    const { requests, fetchImpl } = mockRpc({ pendingPolls: 0, hashEncoding: "raw" });
    const cb = makeCoinbase({ owner, subAccount: SUB, mainAccount: MAIN, fetchImpl, sleep: async () => {} });
    await cb.sendCalls(calls);
    expect(await recoverAddress({ hash: HASH, signature: requests[1].body.params[0].signature.data.signature })).toBe(owner.address);
  });
  it("includes paymasterService in capabilities when PAYMASTER_URL is set", async () => {
    const { requests, fetchImpl } = mockRpc({ pendingPolls: 0 });
    const cb = makeCoinbase({ owner, subAccount: SUB, mainAccount: MAIN, paymasterUrl: "https://pm.example/rpc", fetchImpl, sleep: async () => {} });
    await cb.sendCalls(calls);
    expect(requests[0].body.params[0].capabilities.paymasterService).toEqual({ url: "https://pm.example/rpc" });
    expect(requests[0].body.params[0].capabilities.funding).toHaveLength(1);
  });
  it("throws when the batch fails (status >= 400)", async () => {
    const { fetchImpl } = mockRpc({ pendingPolls: 1, finalStatus: 500 });
    const cb = makeCoinbase({ owner, subAccount: SUB, mainAccount: MAIN, fetchImpl, sleep: async () => {} });
    await expect(cb.sendCalls(calls)).rejects.toThrow(/batch failed \(500\)/);
  });
  it("times out when the batch never confirms", async () => {
    const { fetchImpl } = mockRpc({ pendingPolls: 1e9 });
    const cb = makeCoinbase({ owner, subAccount: SUB, mainAccount: MAIN, fetchImpl, sleep: async () => {} });
    await expect(cb.waitFor("0xid", { attempts: 3 })).rejects.toThrow(/Timed out/);
  });
  it("surfaces JSON-RPC errors with their code", async () => {
    const fetchImpl = async () => ({ json: async () => ({ jsonrpc: "2.0", id: 1, error: { code: -32001, message: "insufficient spend permission" } }) });
    const cb = makeCoinbase({ owner, subAccount: SUB, mainAccount: MAIN, fetchImpl });
    const err = await cb.prepare(calls).catch((e) => e);
    expect(err.message).toBe("insufficient spend permission"); expect(err.code).toBe(-32001);
  });
  it("refuses a sendPreparedCalls response without a batch id", async () => {
    const fetchImpl = async (_u, init) => {
      const m = JSON.parse(init.body).method;
      return { json: async () => ({ result: m === "wallet_prepareCalls" ? { type: "t", userOp: {}, chainId: CHAIN_ID_HEX, signatureRequest: { hash: HASH } } : [] }) };
    };
    const cb = makeCoinbase({ owner, subAccount: SUB, mainAccount: MAIN, fetchImpl });
    await expect(cb.sendCalls(calls)).rejects.toThrow(/no batch id/);
  });
});
