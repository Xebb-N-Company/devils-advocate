import { describe, it, expect } from "vitest";
import { loadConfig } from "../src/config.js";

const SUB = "0x00000000000000000000000000000000000000a1";
describe("config", () => {
  it("defaults: DRY_RUN=1, flow, risk 50, $25 budget, 60s ticks, ./state.json", () => {
    const c = loadConfig({ SUB_ACCOUNT: SUB });
    expect(c.dryRun).toBe(true); expect(c.mode).toBe("flow"); expect(c.risk).toBe(50); expect(c.budgetUsdc).toBe(25);
    expect(c.tickSeconds).toBe(60); expect(c.stateFile).toBe("./state.json"); expect(c.paymasterUrl).toBe("");
    expect(c.coinbaseRpcUrl).toBe("https://rpc.wallet.coinbase.com");
  });
  it("requires SUB_ACCOUNT, and the owner key + main account only when live", () => {
    expect(() => loadConfig({})).toThrow(/SUB_ACCOUNT/);
    expect(() => loadConfig({ SUB_ACCOUNT: SUB, DRY_RUN: "0" })).toThrow(/OWNER_PRIVATE_KEY/);
    expect(() => loadConfig({ SUB_ACCOUNT: SUB, DRY_RUN: "0", OWNER_PRIVATE_KEY: "0x" + "11".repeat(32) })).toThrow(/MAIN_ACCOUNT/);
    const c = loadConfig({ SUB_ACCOUNT: SUB, DRY_RUN: "0", OWNER_PRIVATE_KEY: "0x" + "11".repeat(32), MAIN_ACCOUNT: "0x000000000000000000000000000000000000dEaD" });
    expect(c.dryRun).toBe(false); expect(c.mainAccount.toLowerCase()).toBe("0x000000000000000000000000000000000000dead");
  });
  it("rejects RISK outside 0..100 and unknown modes", () => {
    expect(() => loadConfig({ SUB_ACCOUNT: SUB, RISK: "150" })).toThrow(/RISK/);
    expect(() => loadConfig({ SUB_ACCOUNT: SUB, RISK: "-5" })).toThrow(/RISK/);
    expect(loadConfig({ SUB_ACCOUNT: SUB, RISK: "90" }).risk).toBe(90);
    expect(() => loadConfig({ SUB_ACCOUNT: SUB, MODE: "yolo" })).toThrow(/MODE/);
  });
});
