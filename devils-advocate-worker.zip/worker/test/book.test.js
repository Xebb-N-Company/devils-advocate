import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { isAddress } from "viem";
const book = JSON.parse(readFileSync(new URL("../src/book.json", import.meta.url)));

describe("book.json (extracted from the site bundle, not hand-typed)", () => {
  it("has 55 Uniswap V3 coins and 26 aggregator coins", () => {
    expect(book.v3).toHaveLength(55); expect(book.agg).toHaveLength(26);
    expect(book.source).toMatch(/routes-.*\.js$/);
  });
  it("every entry has a lowercase checksummable address, decimals, base and fee", () => {
    for (const c of [...book.v3, ...book.agg]) {
      expect(isAddress(c.address)).toBe(true); expect(c.address).toBe(c.address.toLowerCase());
      expect(typeof c.symbol).toBe("string"); expect(Number.isInteger(c.decimals)).toBe(true);
      expect(["WETH", "USDC"]).toContain(c.base);
    }
    for (const c of book.v3) expect([100, 500, 3000, 10000]).toContain(c.fee); // the site lists ELONRWA on the 0.01% tier
    for (const c of book.agg) expect(c.agg).toBe(true);
  });
  it("no duplicate symbols or addresses", () => {
    const all = [...book.v3, ...book.agg];
    expect(new Set(all.map((c) => c.symbol)).size).toBe(all.length);
    expect(new Set(all.map((c) => c.address)).size).toBe(all.length);
  });
  it("carries the site constants", () => {
    const k = book.constants;
    expect(k.USDC).toBe("0x833589fcd6edb6e08f4c7c32d4f71b54bda02913");
    expect(k.WETH).toBe("0x4200000000000000000000000000000000000006");
    expect(k.SWAP_ROUTER02).toBe("0x2626664c2603336e57b271c5c0b26f421741e481");
    expect(k.QUOTER_V2).toBe("0x3d4e44eb1374240ce5f1b871ab261cd16335b76a");
    expect(k.FEE_TIERS).toEqual([500, 3000, 10000]);
    expect(k.LIVE_MIN_CLIP).toBe(1); expect(k.LIVE_MAX_ROUNDTRIP).toBeCloseTo(0.06); expect(k.KY_SLIPPAGE_BPS).toBe(300);
  });
});
