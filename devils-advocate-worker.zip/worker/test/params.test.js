import { describe, it, expect } from "vitest";
import { buildParams, riskScale, KEEL_COMMON, KEEL_MODES, riskLabel } from "../src/params.js";

const close = (a, b, eps = 1e-9) => expect(Math.abs(a - b)).toBeLessThan(eps);

describe("riskScale matches the browser numbers (Flow)", () => {
  it("Risk 50 = mode as designed: 25% size, max 4, stop 6%, imb5 .3, minTx5 8, accel 1.5", () => {
    const p = buildParams("flow", 50);
    close(p.size, 0.25); expect(p.maxPos).toBe(4); close(p.stop, 0.06);
    close(p.imb5, 0.3); expect(p.minTx5).toBe(8); close(p.accel, 1.5);
    close(p.trail, 0.04); close(p.trailArm, 0.06); expect(p.timeTicks).toBe(45); expect(p.cooldown).toBe(10); close(p.dayLoss, 0.25);
    close(p.flipImb, -0.3); close(p.c5, 0.5); close(p.minVol1, 2e4); close(p.minLiq, 1e5); close(p.imb1, 0.1);
  });
  it("Risk 90 = 35% size, max 6, stop 8.4%, imb5 .18 (59% buys), minTx5 5, accel .9", () => {
    const p = buildParams("flow", 90);
    close(p.size, 0.35); expect(p.maxPos).toBe(6); close(p.stop, 0.084);
    close(p.imb5, 0.18); expect(Math.round(((1 + p.imb5) / 2) * 100)).toBe(59);
    expect(p.minTx5).toBe(5); close(p.accel, 0.9);
    close(p.dayLoss, 0.35); expect(p.cooldown).toBe(6);
  });
  it("Risk 10 = 15% size, max 2, stop 3.6%, imb5 .42, minTx5 11, accel 2.1", () => {
    const p = buildParams("flow", 10);
    close(p.size, 0.15); expect(p.maxPos).toBe(2); close(p.stop, 0.036);
    close(p.imb5, 0.42); expect(p.minTx5).toBe(11); close(p.accel, 2.1);
    close(p.dayLoss, 0.15); expect(p.cooldown).toBe(14);
  });
  it("Risk 100 / 0 edges: size caps, floors, trail untouched", () => {
    const hi = buildParams("flow", 100), lo = buildParams("flow", 0);
    close(hi.size, 0.375); expect(hi.maxPos).toBe(6); close(hi.stop, 0.09); expect(hi.minTx5).toBe(4); expect(hi.cooldown).toBe(5);
    close(lo.size, 0.125); expect(lo.maxPos).toBe(2); close(lo.stop, 0.03); expect(lo.minTx5).toBe(12); expect(lo.cooldown).toBe(15);
    close(hi.trail, 0.04); close(lo.trail, 0.04); close(hi.trailArm, 0.06);
    expect(hi.flow).toBe(true);
  });
  it("does not scale maxPos for unlimited books (classic 999) and leaves 1e9 trailArm alone", () => {
    const c = buildParams("classic", 90);
    expect(c.maxPos).toBe(999); expect(c.trailArm).toBe(1e9); close(c.stop, 0.035); close(c.entry, 0.025 * 0.6);
  });
  it("riskScale is a pure copy: common + mode merged first", () => {
    const merged = Object.assign({}, KEEL_COMMON, KEEL_MODES.flow);
    expect(riskScale(merged, 0.5)).toEqual(buildParams("flow", 50));
    close(riskScale(merged, 0.5).launchStop, 0.2);
  });
  it("riskLabel bands", () => {
    expect(riskLabel(10)).toBe("Cautious"); expect(riskLabel(50)).toBe("Balanced"); expect(riskLabel(90)).toBe("Reckless");
  });
});
