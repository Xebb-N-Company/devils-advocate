import { describe, it, expect } from "vitest";
import { buildParams } from "../src/params.js";
import { flowScore, dsPrices } from "../src/flow.js";
import { freshState, manageExits, pickEntriesFlow, runEntriesFlow, simulateTick, closeLot, pruneLots, pickEntriesClassic } from "../src/strategy.js";

const P = buildParams("flow", 50);
const coins = [
  { symbol: "AAA", address: "0xa", decimals: 18, base: "WETH", fee: 3000 },
  { symbol: "BBB", address: "0xb", decimals: 18, base: "USDC", fee: 10000 },
  { symbol: "CCC", address: "0xc", decimals: 18, base: "USDC", fee: 0, agg: true },
];
// strong buy pressure: 20 buys / 4 sells in 5m, 100/60 over the hour, 5m volume 3x hourly pace, +2% in 5m
const hot = { b5: 20, s5: 4, b1: 100, s1: 60, v5: 1e4, v1: 4e4, v24: 1e6, liq: 5e5, pairs: 2, c5: 2, c1: 5, c6: 1 };
const quiet = { b5: 5, s5: 5, b1: 50, s1: 50, v5: 1e3, v1: 4e4, v24: 1e6, liq: 5e5, pairs: 1, c5: 0.1, c1: 1, c6: 1 };
// heavy selling: 2 buys / 18 sells, price down
const dump = { b5: 2, s5: 18, b1: 50, s1: 70, v5: 1e4, v1: 4e4, v24: 1e6, liq: 5e5, pairs: 1, c5: -3, c1: -2, c6: 1 };

function ctx({ usdc = 100, tokens = {}, prices = { AAA: 1, BBB: 2, CCC: 0.5 }, flow = {}, state = freshState(), params = P, now = 1_000_000 } = {}) {
  return { coins, balances: { eth: 0, usdc, spare: 0, tokens }, prices, ethUsd: 2000, flow, state, params, now };
}
const hold = (amount) => ({ raw: BigInt(Math.round(amount * 1e18)), amount });

describe("flowScore", () => {
  it("computes imbalance, acceleration and score like the browser", () => {
    const F = flowScore(hot);
    expect(F.n5).toBe(24); expect(F.imb5).toBeCloseTo(16 / 24); expect(F.imb1).toBeCloseTo(40 / 160);
    expect(F.accel).toBeCloseTo(3); expect(F.score).toBeCloseTo((16 / 24) * 3);
    expect(flowScore(undefined)).toBeNull();
  });
  it("caps acceleration at 4 in the score", () => {
    const F = flowScore({ ...hot, v5: 1e5 }); // 30x pace
    expect(F.accel).toBeCloseTo(30); expect(F.score).toBeCloseTo((16 / 24) * 4);
  });
});

describe("dsPrices", () => {
  it("batches 30 addresses per call, picks the most liquid pair for price and sums flow across pairs", async () => {
    const urls = [];
    const fetchImpl = async (url) => {
      urls.push(url);
      const body = [
        { baseToken: { address: "0xA" }, priceUsd: "1.0", liquidity: { usd: 1000 }, txns: { m5: { buys: 1, sells: 2 }, h1: { buys: 10, sells: 20 } }, volume: { m5: 100, h1: 1000, h24: 5000 }, priceChange: { m5: 1, h1: 2, h6: 3 } },
        { baseToken: { address: "0xa" }, priceUsd: "1.1", liquidity: { usd: 5000 }, txns: { m5: { buys: 3, sells: 4 }, h1: { buys: 30, sells: 40 } }, volume: { m5: 200, h1: 2000, h24: 9000 }, priceChange: { m5: 5, h1: 6, h6: 7 } },
      ];
      return { ok: true, json: async () => body };
    };
    const addrs = Array.from({ length: 31 }, (_, i) => "0x" + i.toString(16));
    const { prices, flow } = await dsPrices(addrs, fetchImpl);
    expect(urls.length).toBe(2);
    expect(urls[0].split(",").length).toBe(30);
    expect(prices["0xa"]).toBe(1.1);
    // 0xa was only requested in batch 1, so the (identical) batch-2 body must not double count it
    expect(flow["0xa"].b5).toBe(4); expect(flow["0xa"].s5).toBe(6); expect(flow["0xa"].v1).toBe(3000); expect(flow["0xa"].liq).toBe(6000); expect(flow["0xa"].pairs).toBe(2);
    expect(flow["0xa"].c5).toBe(5); // from the most liquid pair
  });
  it("swallows failed batches", async () => {
    const { prices } = await dsPrices(["0x1"], async () => { throw new Error("boom"); });
    expect(prices).toEqual({});
  });
});

describe("Flow entries", () => {
  it("enters the hottest coin first, sizing 25% of equity, up to maxPos", async () => {
    const c = ctx({ usdc: 100, flow: { AAA: hot, BBB: { ...hot, v5: 2e4 }, CCC: quiet } });
    const r = await simulateTick(c);
    expect(r.candidates.map((x) => x.tok.symbol)).toEqual(["BBB", "AAA"]); // BBB has the higher accel → score
    expect(r.fills.length).toBe(2);
    expect(r.fills[0].usd).toBeCloseTo(25); // 25% of $100 equity
    expect(r.fills[1].usd).toBeCloseTo(25);
    expect(c.state.lots.BBB.entry).toBe(2);
    expect(c.state.lots.AAA.opened).toBe(1);
  });
  it("rejects coins failing any gate (n5, vol, liq, imb5, imb1, accel, c5, c1)", () => {
    const st = freshState(); st.tick = 1;
    const gate = (f) => pickEntriesFlow({ coins, prices: { AAA: 1 }, flow: { AAA: f }, state: st, params: P, held: [], paused: false }).length;
    expect(gate(hot)).toBe(1);
    expect(gate({ ...hot, b5: 4, s5: 1 })).toBe(0);              // n5 5 < 8
    expect(gate({ ...hot, v1: 1e4, v5: 2.5e3 })).toBe(0);        // v1 < 20k
    expect(gate({ ...hot, liq: 5e4 })).toBe(0);                 // liq < 100k
    expect(gate({ ...hot, b5: 13, s5: 11 })).toBe(0);           // imb5 .08 < .3
    expect(gate({ ...hot, b1: 50, s1: 50 })).toBe(0);           // imb1 0 < .1
    expect(gate({ ...hot, v5: 4e3 })).toBe(0);                  // accel 1.2 < 1.5
    expect(gate({ ...hot, c5: 0.2 })).toBe(0);                  // c5 < .5
    expect(gate({ ...hot, c1: -1 })).toBe(0);                   // c1 must be > 0
  });
  it("stops at maxPos and never buys below LIVE_MIN_CLIP", async () => {
    const st = freshState();
    const many = Array.from({ length: 6 }, (_, i) => ({ symbol: "T" + i, address: "0x" + i, decimals: 18, base: "USDC", fee: 3000 }));
    const prices = Object.fromEntries(many.map((c) => [c.symbol, 1]));
    const flow = Object.fromEntries(many.map((c, i) => [c.symbol, { ...hot, v5: 1e4 + i }]));
    const c = { coins: many, balances: { eth: 0, usdc: 100, spare: 0, tokens: {} }, prices, ethUsd: 2000, flow, state: st, params: P, now: 1 };
    const r = await simulateTick(c);
    expect(r.fills.length).toBe(4);
    const tiny = { coins: many, balances: { eth: 0, usdc: 0.8, spare: 0, tokens: {} }, prices, ethUsd: 2000, flow, state: freshState(), params: P, now: 1 };
    expect((await simulateTick(tiny)).fills.length).toBe(0);
  });
  it("skips (does not stop) a coin whose round trip is too thin", async () => {
    const c = ctx({ usdc: 100, flow: { AAA: { ...hot, v5: 2e4 }, BBB: hot } });
    const r = await simulateTick(c, { roundTrip: async (tok) => (tok.symbol === "AAA" ? 0.9 : 0.97) });
    expect(r.fills.map((f) => f.tok.symbol)).toEqual(["BBB"]);
    expect(r.notes.some((n) => /AAA shows buy pressure but the pool is too thin \(round trip 10.0% loss\)/.test(n.text))).toBe(true);
    expect(r.fills[0].usd).toBeCloseTo(25); // AAA's skip did not consume cash
  });
  it("spare main-wallet USDC counts as cash and equity", async () => {
    const c = ctx({ usdc: 0, flow: { AAA: hot } });
    c.balances.spare = 25;
    const r = await simulateTick(c);
    expect(r.fills.length).toBe(1);
    expect(r.fills[0].usd).toBeCloseTo(6.25);
  });
});

describe("Flow exits", () => {
  it("stops out at -6% from entry", () => {
    const st = freshState(); st.tick = 5; st.lots.AAA = { entry: 1, peak: 1, opened: 1, stop: 0.06 };
    const r = manageExits(ctx({ tokens: { AAA: hold(10) }, prices: { AAA: 0.939 }, flow: { AAA: quiet }, state: st }));
    expect(r.sells.length).toBe(1); expect(r.sells[0].kind).toBe("stop"); expect(r.sells[0].reason).toMatch(/Down 6.1% from the entry. Stopped./);
    const r2 = manageExits(ctx({ tokens: { AAA: hold(10) }, prices: { AAA: 0.95 }, flow: { AAA: quiet }, state: st }));
    expect(r2.sells.length).toBe(0); expect(r2.held).toEqual(["AAA"]);
  });
  it("trails 4% off the peak only once up 6%", () => {
    const st = freshState(); st.tick = 5;
    st.lots.AAA = { entry: 1, peak: 1.05, opened: 1, stop: 0.06 };
    expect(manageExits(ctx({ tokens: { AAA: hold(10) }, prices: { AAA: 1.0 }, flow: { AAA: quiet }, state: st })).sells.length).toBe(0); // peak < 1.06: not armed
    st.lots.AAA = { entry: 1, peak: 1.10, opened: 1, stop: 0.06 };
    const r = manageExits(ctx({ tokens: { AAA: hold(10) }, prices: { AAA: 1.055 }, flow: { AAA: quiet }, state: st }));
    expect(r.sells[0].kind).toBe("trail"); expect(r.sells[0].reason).toMatch(/Gave back 4.1% from the peak \(\+10.0%\). Locked the gain./);
    st.lots.AAA = { entry: 1, peak: 1.10, opened: 1, stop: 0.06 };
    expect(manageExits(ctx({ tokens: { AAA: hold(10) }, prices: { AAA: 1.07 }, flow: { AAA: quiet }, state: st })).sells.length).toBe(0);
  });
  it("peak updates every tick", () => {
    const st = freshState(); st.tick = 5; st.lots.AAA = { entry: 1, peak: 1, opened: 1, stop: 0.06 };
    manageExits(ctx({ tokens: { AAA: hold(10) }, prices: { AAA: 1.2 }, flow: {}, state: st }));
    expect(st.lots.AAA.peak).toBe(1.2);
  });
  it("exits on a flow flip (imb5 <= -.3 with >= minTx5 trades and price down in 5m)", () => {
    const st = freshState(); st.tick = 5; st.lots.AAA = { entry: 1, peak: 1.02, opened: 1, stop: 0.06 };
    const r = manageExits(ctx({ tokens: { AAA: hold(10) }, prices: { AAA: 1.01 }, flow: { AAA: dump }, state: st }));
    expect(r.sells[0].kind).toBe("flip"); expect(r.sells[0].reason).toMatch(/Flow flipped: 90% of the last 5 minutes were sells. Out at \+1.0%./); expect(r.sells[0].tone).toBe("ok");
    const noDrop = manageExits(ctx({ tokens: { AAA: hold(10) }, prices: { AAA: 1.01 }, flow: { AAA: { ...dump, c5: 0.5 } }, state: freshStateWith(5) }));
    expect(noDrop.sells.length).toBe(0);
    const fewTrades = manageExits(ctx({ tokens: { AAA: hold(10) }, prices: { AAA: 1.01 }, flow: { AAA: { ...dump, b5: 1, s5: 5 } }, state: freshStateWith(5) }));
    expect(fewTrades.sells.length).toBe(0);
  });
  it("time stop: flat (|pnl| <= 2%) after 45 ticks", () => {
    const st = freshState(); st.tick = 46; st.lots.AAA = { entry: 1, peak: 1.01, opened: 1, stop: 0.06 };
    const r = manageExits(ctx({ tokens: { AAA: hold(10) }, prices: { AAA: 1.01 }, flow: { AAA: quiet }, state: st }));
    expect(r.sells[0].kind).toBe("time"); expect(r.sells[0].reason).toBe("Flat for 45 ticks. Time stop.");
    st.tick = 45; st.lots.AAA = { entry: 1, peak: 1.01, opened: 1, stop: 0.06 };
    expect(manageExits(ctx({ tokens: { AAA: hold(10) }, prices: { AAA: 1.01 }, flow: { AAA: quiet }, state: st })).sells.length).toBe(0); // 44 ticks: not yet
    st.tick = 60; st.lots.AAA = { entry: 1, peak: 1.04, opened: 1, stop: 0.06 };
    expect(manageExits(ctx({ tokens: { AAA: hold(10) }, prices: { AAA: 1.04 }, flow: { AAA: quiet }, state: st })).sells.length).toBe(0); // +4%: not flat
  });
  it("adopts an unknown holding as a lot at the current price with the mode stop", () => {
    const st = freshState(); st.tick = 3;
    const r = manageExits(ctx({ tokens: { BBB: hold(5) }, prices: { BBB: 2 }, flow: {}, state: st }));
    expect(r.held).toEqual(["BBB"]); expect(st.lots.BBB).toMatchObject({ entry: 2, peak: 2, opened: 3, stop: 0.06 });
  });
  it("ignores dust under $0.50", () => {
    const r = manageExits(ctx({ tokens: { AAA: hold(0.4) }, prices: { AAA: 1 }, flow: {}, state: freshState() }));
    expect(r.held).toEqual([]);
  });
  it("prunes lots that are neither held nor just sold (a failed sell keeps its lot)", () => {
    const st = freshState(); st.lots.AAA = { entry: 1 }; st.lots.BBB = { entry: 1 }; st.lots.CCC = { entry: 1 };
    pruneLots(st, ["AAA"], ["BBB"]);
    expect(Object.keys(st.lots).sort()).toEqual(["AAA", "BBB"]);
  });
});

function freshStateWith(tick) { const s = freshState(); s.tick = tick; s.lots.AAA = { entry: 1, peak: 1.02, opened: 1, stop: 0.06 }; return s; }

describe("cooldown", () => {
  it("blocks re-entry for `cooldown` ticks after a full sale, then allows it", async () => {
    const st = freshState(); st.tick = 10; st.lots.AAA = { entry: 1, peak: 1, opened: 1, stop: 0.06 };
    const c = ctx({ usdc: 50, tokens: { AAA: hold(10) }, prices: { AAA: 0.9 }, flow: { AAA: hot }, state: st });
    const r = await simulateTick(c); // tick 11: stop out, cooldown starts at 11
    expect(r.sold).toEqual(["AAA"]); expect(st.cool.AAA).toBe(11); expect(r.fills.length).toBe(0);
    // ticks 12..20: AAA is hot but cooling (11 + 10 = 21 is the first tick allowed)
    for (let t = 12; t <= 20; t++) {
      const rr = await simulateTick(c);
      expect(rr.candidates.length).toBe(0);
    }
    const back = await simulateTick(c); // tick 21
    expect(back.candidates.map((x) => x.tok.symbol)).toEqual(["AAA"]);
    expect(back.fills.length).toBe(1);
  });
  it("closeLot clears the lot and the classic reference", () => {
    const st = freshState(); st.tick = 7; st.lots.AAA = { entry: 1 }; st.ref.AAA = 1;
    closeLot(st, "AAA");
    expect(st.lots.AAA).toBeUndefined(); expect(st.ref.AAA).toBeUndefined(); expect(st.cool.AAA).toBe(7);
  });
});

describe("daily loss cap", () => {
  it("pauses entries once equity drops 25% from the day's starting NAV, still manages exits, resets after 24h", async () => {
    const st = freshState();
    const c = ctx({ usdc: 100, flow: { AAA: hot }, state: st, now: 1_000_000 });
    c.flow = {}; // nothing hot on the first tick: just set the day NAV
    let r = await simulateTick(c);
    expect(st.day.nav).toBe(100); expect(r.paused).toBe(false);
    // equity collapses to $74 (a held coin tanked) — stop fires, no new entries even though BBB is hot
    st.lots.AAA = { entry: 1, peak: 1, opened: 1, stop: 0.06 };
    c.balances.usdc = 0; c.balances.tokens = { AAA: hold(74) }; c.prices = { AAA: 1, BBB: 2 }; c.flow = { AAA: quiet, BBB: hot };
    r = await simulateTick(c);
    expect(r.paused).toBe(true); expect(r.candidates.length).toBe(0); expect(r.fills.length).toBe(0);
    expect(r.notes.some((n) => /Daily loss cap hit \(−25%\)/.test(n.text))).toBe(true);
    // a stop still executes while paused
    c.prices = { AAA: 0.9, BBB: 2 };
    r = await simulateTick(c);
    expect(r.sold).toEqual(["AAA"]);
    // next day: NAV resets to current equity and trading resumes
    c.now = 1_000_000 + 864e5; c.flow = { BBB: hot }; c.prices = { BBB: 2 };
    r = await simulateTick(c);
    expect(r.paused).toBe(false); expect(st.day.nav).toBeCloseTo(66.6); expect(r.fills.length).toBe(1);
  });
  it("Risk 10 caps at 15%, Risk 90 at 35%", async () => {
    for (const [risk, cap] of [[10, 0.15], [90, 0.35]]) {
      const st = freshState(); st.day = { t: 1, nav: 100 };
      const c = ctx({ usdc: 100 * (1 - cap) + 0.01, flow: { AAA: hot }, state: st, params: buildParams("flow", risk), now: 2 });
      expect(manageExits(c).paused).toBe(false);
      c.balances.usdc = 100 * (1 - cap) - 0.01;
      expect(manageExits(c).paused).toBe(true);
    }
  });
});

describe("Classic slot", () => {
  it("sets the reference on first sight and flags +2.5% moves", () => {
    const st = freshState(); const cp = buildParams("classic", 50);
    expect(pickEntriesClassic({ coins, prices: { AAA: 1 }, state: st, params: cp, held: [] })).toEqual([]);
    expect(st.ref.AAA).toBe(1);
    const r = pickEntriesClassic({ coins, prices: { AAA: 1.03 }, state: st, params: cp, held: [] });
    expect(r.length).toBe(1); expect(r[0].move).toBeCloseTo(0.03);
  });
});
