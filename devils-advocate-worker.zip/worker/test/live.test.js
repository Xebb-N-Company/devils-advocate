// One real DRY_RUN tick against DexScreener + Base RPC. Needs network; run with `npm run test:live` (LIVE_TEST=1).
import { describe, it, expect } from "vitest";
import { spawnSync } from "node:child_process";

const live = process.env.LIVE_TEST === "1";
describe.skipIf(!live)("live DRY_RUN tick (npm run tick:dry)", () => {
  it("prices the book, prints decisions, never POSTs to Coinbase, and exits 0", () => {
    const r = spawnSync("npm", ["run", "-s", "tick:dry"], { encoding: "utf8", timeout: 240_000, env: { ...process.env, MODE: "flow", /* vitest exports MODE=test */ SUB_ACCOUNT: "0x0000000000000000000000000000000000000001", STATE_FILE: "/tmp/da-live-test-state.json" } });
    const out = r.stdout + r.stderr;
    expect(r.status, out).toBe(0);
    expect(out).toMatch(/DRY_RUN/);
    expect(out).toMatch(/tick \d+ · ETH \$[\d.]+ · \d+\/81 priced/);
    expect(out).toMatch(/equity \$/);
    expect(out).not.toMatch(/Coinbase Wallet batch/);
  }, 250_000);
});
